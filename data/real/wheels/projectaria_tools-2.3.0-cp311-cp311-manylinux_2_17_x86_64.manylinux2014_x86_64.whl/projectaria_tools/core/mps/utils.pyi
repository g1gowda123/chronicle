from __future__ import annotations
import projectaria_tools.core.calibration
from projectaria_tools.core.calibration import CameraCalibration
from projectaria_tools.core.calibration import DeviceCalibration
import projectaria_tools.core.mps
from projectaria_tools.core.mps import ClosedLoopTrajectoryPose
from projectaria_tools.core.mps import EyeGaze
from projectaria_tools.core.mps import GlobalPointPosition
from projectaria_tools.core.mps import OpenLoopTrajectoryPose
from projectaria_tools.core.mps import hand_tracking
import projectaria_tools.core.mps.hand_tracking
from projectaria_tools.core.mps.pybind11_detail_function_record_v1_system_libstdcpp_gxx_abi_1xxx_use_cxx11_abi_1 import get_eyegaze_point_at_depth
from projectaria_tools.core.sophus import SE3
import numpy as np
import typing
__all__ = ['CameraCalibration', 'ClosedLoopTrajectoryPose', 'DeviceCalibration', 'EyeGaze', 'GlobalPointPosition', 'List', 'OpenLoopTrajectoryPose', 'Optional', 'SE3', 'Union', 'bisection_timestamp_search', 'filter_points_from_confidence', 'filter_points_from_count', 'get_eyegaze_point_at_depth', 'get_gaze_vector_reprojection', 'get_nearest_eye_gaze', 'get_nearest_hand_tracking_result', 'get_nearest_pose', 'get_nearest_wrist_and_palm_pose', 'hand_tracking', 'np']
def bisection_timestamp_search(timed_data, query_timestamp_ns: int) -> int:
    """
    
        Binary search helper function, assuming that timed_data is sorted by the field names 'tracking_timestamp'
        Returns index of the element closest to the query timestamp else returns None if not found (out of time range)
        
    """
def filter_points_from_confidence(raw_points: typing.List[projectaria_tools.core.mps.GlobalPointPosition], threshold_invdep: float = 0.001, threshold_dep: float = 0.05) -> typing.List[projectaria_tools.core.mps.GlobalPointPosition]:
    """
    
        Filter the point cloud by inv depth and depth
        
    """
def filter_points_from_count(raw_points: typing.List[projectaria_tools.core.mps.GlobalPointPosition], max_point_count: int = 500000) -> typing.List[projectaria_tools.core.mps.GlobalPointPosition]:
    """
    
        Filter the point cloud by count (random points are sampled from the initial set)
        
    """
def get_gaze_vector_reprojection(eye_gaze: projectaria_tools.core.mps.EyeGaze, stream_id_label: str, device_calibration: projectaria_tools.core.calibration.DeviceCalibration, camera_calibration: projectaria_tools.core.calibration.CameraCalibration, depth_m: float = 1.0, make_upright: bool = ...) -> typing.Optional[numpy.ndarray]:
    """
    
        Helper function to project a eye gaze output onto a given image and its calibration.
    
        When `eye_gaze.spatial_gaze_point_valid` is True (the vergence-point geometry available
        on Gen2 ET outputs), `eye_gaze.spatial_gaze_point_in_cpf` is projected directly. Otherwise
        the gaze is reconstructed from combined yaw/pitch scaled by `depth_m`.
    
        If no reprojection is possible (e.g. the eye gaze is out of the
        field of view), then None is returned. See `CameraCalibration::project()`
        (in CameraCalibration.h) for details.
        
    """
def get_nearest_eye_gaze(eye_gazes: typing.List[projectaria_tools.core.mps.EyeGaze], query_timestamp_ns: int) -> projectaria_tools.core.mps.EyeGaze:
    """
    
        Helper function to get nearest eye gaze for a timestamp (ns)
        Return the closest or equal timestamp eye_gaze information that can be found, returns None if not found (out of time range)
        
    """
def get_nearest_hand_tracking_result(hand_tracking_results: typing.List[projectaria_tools.core.mps.hand_tracking.HandTrackingResult], query_timestamp_ns: int) -> projectaria_tools.core.mps.hand_tracking.HandTrackingResult:
    """
    
        Helper function to get nearest hand tracking result for a timestamp (ns)
        Return the closest or equal timestamp hand tracking result that can be found, returns None if not found (out of time range)
        
    """
def get_nearest_pose(mps_trajectory: typing.List[typing.Union[projectaria_tools.core.mps.ClosedLoopTrajectoryPose, projectaria_tools.core.mps.OpenLoopTrajectoryPose]], query_timestamp_ns: int) -> typing.Union[projectaria_tools.core.mps.ClosedLoopTrajectoryPose, projectaria_tools.core.mps.OpenLoopTrajectoryPose]:
    """
    
        Helper function to get nearest pose for a timestamp (ns)
        Return the closest or equal timestamp pose information that can be found, returns None if not found (out of time range)
        
    """
def get_nearest_wrist_and_palm_pose(wirst_and_palm_poses: typing.List[projectaria_tools.core.mps.hand_tracking.WristAndPalmPose], query_timestamp_ns: int) -> projectaria_tools.core.mps.hand_tracking.WristAndPalmPose:
    """
    
        Helper function to get nearest wrist and palm pose for a timestamp (ns)
        Return the closest or equal timestamp wrist and palm pose that can be found, returns None if not found (out of time range)
        
    """
List: typing._SpecialGenericAlias  # value = typing.List
Optional: typing._SpecialForm  # value = typing.Optional
Union: typing._SpecialForm  # value = typing.Union
