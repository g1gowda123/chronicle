from __future__ import annotations
import projectaria_tools.core.image
import collections.abc
import numpy
import numpy.typing
import typing
__all__ = ['ARIA_ET_CALIBRATION', 'ARIA_MIC_CALIBRATION', 'BAROMETER_CALIBRATION', 'BarometerCalibration', 'CALIBRATED_ALL', 'CAMERA_CALIBRATION', 'CameraCalibration', 'CameraModelType', 'CameraProjection', 'CpfType', 'DeviceCadExtrinsics', 'DeviceCalibration', 'DeviceVersion', 'FISHEYE62', 'FISHEYE624', 'GYRO_ONLINE_BIAS', 'Gen1', 'Gen2', 'IMU_CALIBRATION', 'ImuCalibration', 'KANNALA_BRANDT_K3', 'LINEAR', 'LinearRectificationModel3d', 'MAGNETOMETER_CALIBRATION', 'MICROPHONE_CALIBRATION', 'MagnetometerCalibration', 'MicrophoneCalibration', 'NEURAL_BAND_BATCH_CALIBRATION', 'NOT_VALID', 'NeuralBandBatchCalibration', 'NeuralBandEmgCalibration', 'NeuralBandImuCalibration', 'NeuralBandImuCalibrationApplied', 'NotValid', 'ONLINE_BIAS', 'SPHERICAL', 'SensorCalibration', 'SensorCalibrationType', 'UNCALIBRATED', 'color_correct', 'device_calibration_from_json', 'device_calibration_from_json_string', 'device_calibration_to_json_string', 'devignetting', 'distort_by_calibration', 'distort_by_calibration_and_apply_rotation', 'distort_depth_by_calibration', 'distort_label_by_calibration', 'from_device_class_name', 'get_linear_camera_calibration', 'get_name', 'get_spherical_camera_calibration', 'rescale_camera_calibration', 'rotate_camera_calib_cw90deg']
class BarometerCalibration:
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    def __getstate__(self) -> tuple[str, float, float]:
        ...
    def __init__(self, arg0: str, arg1: typing.SupportsFloat | typing.SupportsIndex, arg2: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def get_label(self) -> str:
        ...
    def get_offset_pa(self) -> float:
        ...
    def get_slope(self) -> float:
        ...
    def raw_to_rectified(self, raw: typing.SupportsFloat | typing.SupportsIndex) -> float:
        ...
    def rectified_to_raw(self, rectified: typing.SupportsFloat | typing.SupportsIndex) -> float:
        ...
class CameraCalibration:
    """
    A class that provides APIs for camera calibration, including extrinsics, intrinsics, and projection.
    """
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    def __getstate__(self) -> tuple[str, CameraModelType, typing.Annotated[numpy.typing.NDArray[numpy.float64], "[m, 1]"], SE3, typing.Annotated[numpy.typing.NDArray[numpy.int32], "[2, 1]"], float | None, float, str, float, float | None]:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: str, arg1: CameraModelType, arg2: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[m, 1]"], arg3: SE3, arg4: typing.SupportsInt | typing.SupportsIndex, arg5: typing.SupportsInt | typing.SupportsIndex, arg6: typing.SupportsFloat | typing.SupportsIndex | None, arg7: typing.SupportsFloat | typing.SupportsIndex, arg8: str) -> None:
        """
        Constructor with a list of parameters for CameraCalibration.
          Args:
            label: The label of the camera, e.g. "camera-slam-left".
            projection_model_type The type of camera projection model, e.g. ModelType::Linear
            projection_params: The projection parameters.
            T_Device_Camera: The extrinsics of camera in Device frame.
            image_width: Width of camera image.
            image_height: Height of camera image.
            maybe_valid_radius: [optional] radius of a circular mask that represents the valid area on
                    the camera's sensor plane. Pixels out of this circular region are considered invalid. Setting
                    this to None means the entire sensor plane is valid.
            max_solid_angle: an angle theta representing the FOV cone of the camera. Rays out of
                    [-theta, +theta] will be rejected during projection
            serial_number: Serial number of the camera.
        """
    @typing.overload
    def __init__(self, arg0: str, arg1: CameraModelType, arg2: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[m, 1]"], arg3: SE3, arg4: typing.SupportsInt | typing.SupportsIndex, arg5: typing.SupportsInt | typing.SupportsIndex, arg6: typing.SupportsFloat | typing.SupportsIndex | None, arg7: typing.SupportsFloat | typing.SupportsIndex, arg8: str, arg9: typing.SupportsFloat | typing.SupportsIndex) -> None:
        """
        Constructor with a list of parameters for CameraCalibration.
          Args:
            label: The label of the camera, e.g. "camera-slam-left".
            projection_model_type The type of camera projection model, e.g. ModelType::Linear
            projection_params: The projection parameters.
            T_Device_Camera: The extrinsics of camera in Device frame.
            image_width: Width of camera image.
            image_height: Height of camera image.
            maybe_valid_radius: [optional] radius of a circular mask that represents the valid area on
                    the camera's sensor plane. Pixels out of this circular region are considered invalid. Setting
                    this to None means the entire sensor plane is valid.
            max_solid_angle: an angle theta representing the FOV cone of the camera. Rays out of
                    [-theta, +theta] will be rejected during projection
            serial_number: Serial number of the camera.
            time_offset_sec_device_camera: time offset in second between the camera mid exposure time and the capture
            timestamp.
        """
    @typing.overload
    def __init__(self, arg0: str, arg1: CameraModelType, arg2: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[m, 1]"], arg3: SE3, arg4: typing.SupportsInt | typing.SupportsIndex, arg5: typing.SupportsInt | typing.SupportsIndex, arg6: typing.SupportsFloat | typing.SupportsIndex | None, arg7: typing.SupportsFloat | typing.SupportsIndex, arg8: str, arg9: typing.SupportsFloat | typing.SupportsIndex, arg10: typing.SupportsFloat | typing.SupportsIndex | None) -> None:
        """
        Constructor with a list of parameters for CameraCalibration.
          Args:
            label: The label of the camera, e.g. "camera-slam-left".
            projection_model_type The type of camera projection model, e.g. ModelType::Linear
            T_Device_Camera: The extrinsics of camera in Device frame.
            projection_params: The projection parameters.
            image_width: Width of camera image.
            image_height: Height of camera image.
            maybe_valid_radius: [optional] radius of a circular mask that represents the valid area on
                    the camera's sensor plane. Pixels out of this circular region are considered invalid. Setting
                    this to None means the entire sensor plane is valid.
            max_solid_angle: an angle theta representing the FOV cone of the camera. Rays out of
                    [-theta, +theta] will be rejected during projection
            serial_number: Serial number of the camera.
            time_offset_sec_device_camera: time offset in second between the camera mid exposure time and the capture
            timestamp.
            maybe_readout_time_sec: readout time in second to read from the first pixel to the last pixel.
        """
    def __repr__(self) -> str:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def get_focal_lengths(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, 1]"]:
        ...
    def get_image_size(self) -> typing.Annotated[numpy.typing.NDArray[numpy.int32], "[2, 1]"]:
        ...
    def get_label(self) -> str:
        ...
    def get_max_solid_angle(self) -> float:
        ...
    def get_model_name(self) -> CameraModelType:
        ...
    def get_principal_point(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, 1]"]:
        ...
    def get_projection_params(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[m, 1]"]:
        ...
    def get_readout_time_sec(self) -> float | None:
        ...
    def get_serial_number(self) -> str:
        ...
    def get_time_offset_sec_device_camera(self) -> float:
        ...
    def get_transform_device_camera(self) -> SE3:
        ...
    def get_valid_radius(self) -> float | None:
        ...
    def is_visible(self, camera_pixel: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[2, 1]"]) -> bool:
        """
        Function to check whether a pixel is within the valid area of the sensor plane.
        """
    def model_name(self) -> CameraModelType:
        ...
    def num_parameters(self) -> int:
        """
        Return number of calibration parameters.
        """
    def project(self, point_in_camera: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"], jacobian_wrt_point: typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, 3]", "flags.writeable", "flags.f_contiguous"] | None = ..., jacobian_wrt_params: typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, n]", "flags.writeable", "flags.f_contiguous"] | None = ...) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, 1]"] | None:
        """
        Function to project a 3d point (in camera frame) to a 2d camera pixel location, with a number of validity checks to ensure the point is visible. Jacobian arguments, if specified, must be in Fortran style (ie. column-major order):
        
        jacPoint = numpy.empty((3,4),  dtype=np.float64, order='F')
        jacParams = numpy.empty((2, camera.num_parameters()), dtype=np.float64, order='F'))
        pixel = camera.project(world_pt, jacPoint, jacParams)
        """
    def project_no_checks(self, point_in_camera: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"], jacobian_wrt_point: typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, 3]", "flags.writeable", "flags.f_contiguous"] | None = ..., jacobian_wrt_params: typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, n]", "flags.writeable", "flags.f_contiguous"] | None = ...) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, 1]"] | None:
        """
        Function to project a 3d point (in camera frame) to a 2d camera pixel location. In this function, no check is performed. Jacobian arguments, if specified, must be in Fortran style (ie. column-major order):
        
        jacPoint = numpy.empty((3,4),  dtype=np.float64, order='F')
        jacParams = numpy.empty((2, camera.num_parameters()), dtype=np.float64, order='F'))
        pixel = camera.project_no_checks(world_pt, jacPoint, jacParams)
        """
    def projection_params(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[m, 1]"]:
        ...
    def rescale(self, new_resolution: typing.Annotated[numpy.typing.ArrayLike, numpy.int32, "[2, 1]"], scale: typing.SupportsFloat | typing.SupportsIndex, origin_offset: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[2, 1]"] = ...) -> CameraCalibration:
        """
        Obtain a new camera calibration after translation and scaling transform from the original camera calibration. <br> transform is done in the order of (1) shift -> (2) scaling. <r>Note that assymetric cropping is allowed
        """
    def unproject(self, camera_pixel: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[2, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"] | None:
        """
        Function to unproject a 2d pixel location to a 3d ray, in camera frame, with a number of validity checks to ensure the unprojection is valid.
        """
    def unproject_no_checks(self, camera_pixel: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[2, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        Function to unproject a 2d pixel location to a 3d ray in camera frame. In this function, no check is performed.
        """
class CameraModelType:
    """
    Enum that represents the type of camera projection model. See Linear.h, Spherical.h, KannalaBrandtK3.h and FisheyeRadTanThinPrism.h for details.
    
    Members:
    
      KANNALA_BRANDT_K3 : Spherical + polynomial radial distortion up to 9-th order.
    
      FISHEYE624 : Spherical + polynomial radial distortion up to 11-th order + tangential distortion.
    
      SPHERICAL : Spherical projection, linear in angular space.
    
      LINEAR : Linear pinhole projection, unit plane points and camera pixels are linearly related.
    
      FISHEYE62 : Spherical + polynomial radial distortion up to 11-th order.
    """
    FISHEYE62: typing.ClassVar[CameraModelType]  # value = <CameraModelType.FISHEYE62: 4>
    FISHEYE624: typing.ClassVar[CameraModelType]  # value = <CameraModelType.FISHEYE624: 3>
    KANNALA_BRANDT_K3: typing.ClassVar[CameraModelType]  # value = <CameraModelType.KANNALA_BRANDT_K3: 2>
    LINEAR: typing.ClassVar[CameraModelType]  # value = <CameraModelType.LINEAR: 0>
    SPHERICAL: typing.ClassVar[CameraModelType]  # value = <CameraModelType.SPHERICAL: 1>
    __members__: typing.ClassVar[typing.Dict[str, CameraModelType]]  # value = {'KANNALA_BRANDT_K3': <CameraModelType.KANNALA_BRANDT_K3: 2>, 'FISHEYE624': <CameraModelType.FISHEYE624: 3>, 'SPHERICAL': <CameraModelType.SPHERICAL: 1>, 'LINEAR': <CameraModelType.LINEAR: 0>, 'FISHEYE62': <CameraModelType.FISHEYE62: 4>}
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    @typing.overload
    def __eq__(self, other: CameraModelType) -> bool:
        ...
    @typing.overload
    def __eq__(self, other: object) -> bool:
        ...
    @typing.overload
    def __getstate__(self) -> int:
        ...
    @typing.overload
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    @typing.overload
    def __ne__(self, other: CameraModelType) -> bool:
        ...
    @typing.overload
    def __ne__(self, other: object) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    @typing.overload
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @typing.overload
    def __setstate__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(arg0: CameraModelType) -> int:
        ...
class CameraProjection:
    """
    A struct to represent a camera projection instance, which is basically camera intrinsics. This struct stores the intrinsics parameters internally.
    """
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    def __getstate__(self) -> tuple[..., typing.Annotated[numpy.typing.NDArray[numpy.float64], "[m, 1]"]]:
        ...
    @typing.overload
    def __init__(self) -> None:
        """
        Default constructor, creates an empty CameraProjection instance.
        """
    @typing.overload
    def __init__(self, arg0: ..., arg1: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[m, 1]"]) -> None:
        """
        Constructor with a list of parameters for CameraProjection.
                  Args:
                    type: The type of projection model, e.g. ModelType::Linear.
                    projection_params: The projection parameters.
        """
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def get_focal_lengths(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, 1]"]:
        """
        returns focal lengths as {fx, fy}.
        """
    def get_principal_point(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, 1]"]:
        """
        returns principal point location as {cx, cy}.
        """
    def model_name(self) -> ...:
        ...
    def project(self, point_in_camera: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"], jacobian_wrt_point: typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, 3]", "flags.writeable", "flags.f_contiguous"] | None = ..., jacobian_wrt_params: typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, n]", "flags.writeable", "flags.f_contiguous"] | None = ...) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[2, 1]"] | None:
        """
        projects a 3d world point in the camera space to a 2d pixel in the image space. No checks performed in this process. Jacobian arguments, if specified, must be in Fortran style (ie. column-major order):
        
        jacPoint = numpy.empty((3,4),  dtype=np.float64, order='F')
        jacParams = numpy.empty((2, camera.num_parameters()), dtype=np.float64, order='F'))
        pixel = camera.project_no_checks(world_pt, jacPoint, jacParams)
        """
    def projection_params(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[m, 1]"]:
        ...
    def unproject(self, camera_pixel: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[2, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
         No checks performed in this process.
        """
class CpfType:
    """
    A enum class that represents which central pupil frame (CPF) an accessor reports against: CadBased, SvdBased, Default. Default resolves per generation, CadBased on Gen1 and SvdBased on Gen2.
    
    Members:
    
      CadBased
    
      SvdBased
    
      Default
    """
    CadBased: typing.ClassVar[CpfType]  # value = <CpfType.CadBased: 0>
    Default: typing.ClassVar[CpfType]  # value = <CpfType.Default: 2>
    SvdBased: typing.ClassVar[CpfType]  # value = <CpfType.SvdBased: 1>
    __members__: typing.ClassVar[typing.Dict[str, CpfType]]  # value = {'CadBased': <CpfType.CadBased: 0>, 'SvdBased': <CpfType.SvdBased: 1>, 'Default': <CpfType.Default: 2>}
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    @typing.overload
    def __eq__(self, other: CpfType) -> bool:
        ...
    @typing.overload
    def __eq__(self, other: object) -> bool:
        ...
    @typing.overload
    def __getstate__(self) -> int:
        ...
    @typing.overload
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    @typing.overload
    def __ne__(self, other: CpfType) -> bool:
        ...
    @typing.overload
    def __ne__(self, other: object) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    @typing.overload
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @typing.overload
    def __setstate__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(arg0: CpfType) -> int:
        ...
class DeviceCadExtrinsics:
    """
    This class retrieves fixed CAD extrinsics values for Aria Device
    """
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    def __getstate__(self) -> tuple[DeviceVersion, str, str]:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: DeviceVersion, arg1: str, arg2: str) -> None:
        """
        Construct for Cad extrinsics based on device version, device sub type, and origin label, where the label of the origin (`Device` coordinate frame) sensor,e.g. camera-slam-left
        """
    @typing.overload
    def __init__(self, arg0: str, arg1: str) -> None:
        """
        [Deprecated! Please use: DeviceCadExtrinsics(deviceVersion, deviceTypeType, deviceLabel)] Construct for Cad extrinsics for Aria Gen1 only. Input: device sub type, and origin label, where the label of the origin (`Device` coordinate frame) sensor,e.g. camera-slam-left
        """
    def __setstate__(self, arg0: tuple) -> None:
        ...
class DeviceCalibration:
    """
    A class to store and access calibration information of a device, including: camera, imu, magnetometer, barometer, and microphones.
    """
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    def __getstate__(self) -> tuple[dict[str, CameraCalibration], dict[str, ImuCalibration], dict[str, MagnetometerCalibration], dict[str, BarometerCalibration], dict[str, MicrophoneCalibration], DeviceCadExtrinsics, str, str, DeviceVersion]:
        ...
    def __init__(self, camera_calibs: collections.abc.Mapping[str, CameraCalibration] = ..., imu_calibs: collections.abc.Mapping[str, ImuCalibration] = ..., magnetometer_calibs: collections.abc.Mapping[str, MagnetometerCalibration] = ..., barometer_calibs: collections.abc.Mapping[str, BarometerCalibration] = ..., microphone_calibs: collections.abc.Mapping[str, MicrophoneCalibration] = ..., device_cad_extrinsics: DeviceCadExtrinsics = ..., device_subtype: str = ..., origin_label: str = ..., device_version: DeviceVersion = ...) -> None:
        """
        Constructor that composes a collection of sensor calibrations into a DeviceCalibration"
                    " @param camera_calibs: map of <label, CameraCalibration>"
                    " @param imu_calibs: map of <label, ImuCalibration>"
                    " @param magnetometer_calibs: map of <label, MagnetometerCalibration>"
                    " @param barometer_calibs: map of <label, BarometerCalibration>"
                    " @param microphone_calibs: map of <label, MicrophoneCalibration>"
                    " @param device_cad_extrinsics: a struct representing the CAD extrinsics info of the device sensors."
                    " @param device_subtype: the subtype of the device. For Aria, this would be 'DVT-S' or 'DVT-L'."
                    " @param origin_label: the label identifying the origin of the calibration extrinsics, which needs"
                    " to be a sensor within this device. This is basically the 'Device' frame in `T_Device_Sensor`."
                    " @param device_version: the version of the device, {Gen1(default), Gen2}
        """
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def get_all_labels(self) -> list[str]:
        """
        returns all labels for all the sensors.
        """
    def get_aria_et_camera_calib(self) -> typing.Annotated[list[CameraCalibration], "FixedSize(2)"] | None:
        """
        returns an array-of-2 of CameraCalibration representing left and right ET camera calibrations for an Aria device. Will return None if device is not Aria, or it does not contain the valid ET camera.
        """
    def get_aria_microphone_calib(self) -> typing.Annotated[list[MicrophoneCalibration], "FixedSize(7)"] | None:
        """
        returns an array-of-7 of mic calibration for an Aria device. Will return None if device is not Aria, or it does not contain the valid mic calibrations.
        """
    def get_audio_labels(self) -> list[str]:
        """
        returns all labels for calibrated audio sensors, including microphones and speakers.
        """
    def get_barometer_calib(self, label: str) -> projectaria_tools.core.calibration.BarometerCalibration | None:
        """
        returns a barometer calibration by its label. Will return None if label does not exist in device calibration.
        """
    def get_barometer_labels(self) -> list[str]:
        """
        returns all labels for barometers.
        """
    def get_camera_calib(self, label: str) -> projectaria_tools.core.calibration.CameraCalibration | None:
        """
        returns a camera calibration by its label. Will return None if label does not exist in device calibration.
        """
    def get_camera_labels(self) -> list[str]:
        """
        returns all labels for cameras.
        """
    def get_device_subtype(self) -> str:
        """
        Get the subtype of device. For Aria, this is 'DVT-S' or 'DVT-L' to indicate the size of the Aria unit.
        """
    def get_device_version(self) -> DeviceVersion:
        """
        Get the version of device, e.g. Gen1 or Gen2.
        """
    def get_imu_calib(self, label: str) -> projectaria_tools.core.calibration.ImuCalibration | None:
        """
        returns a imu calibration by its label. Will return None if label does not exist in device calibration.
        """
    def get_imu_labels(self) -> list[str]:
        """
        returns all labels for imus.
        """
    def get_magnetometer_calib(self, label: str) -> projectaria_tools.core.calibration.MagnetometerCalibration | None:
        """
        returns a magnetometer calibration by its label. Will return None if label does not exist in device calibration.
        """
    def get_magnetometer_labels(self) -> list[str]:
        """
        returns all labels for magnetometers.
        """
    def get_microphone_calib(self, label: str) -> projectaria_tools.core.calibration.MicrophoneCalibration | None:
        """
        returns a microphone calibration by its label. Will return None if label does not exist in device calibration.
        """
    def get_microphone_labels(self) -> list[str]:
        """
        returns all labels for calibrated microphones.
        """
    def get_origin_label(self) -> str:
        """
        obtain the definition of Origin (or Device in T_Device_Sensor).
        """
    def get_sensor_calib(self, label: str) -> projectaria_tools.core.calibration.SensorCalibration | None:
        """
        returns a sensor calibration by its label. Will return None if label does not exist in device calibration.
        """
    def get_speaker_labels(self) -> list[str]:
        """
        returns all labels for calibrated speakers.
        """
    def get_transform_cpf_sensor(self, label: str, get_cad_value: bool = ..., cpf_type: CpfType = ...) -> SE3 | None:
        """
        returns calibrated sensor extrinsics in CPF frame given a label. `get_cad_value = True` returns the CAD design pose of the sensor instead of the per-instance calibrated one, and is answered from the CAD table; CpfType.SvdBased is rejected there with ValueError, and CpfType.Default stays on CAD.
        """
    def get_transform_device_cpf(self, cpf_type: CpfType = ...) -> SE3:
        """
        returns relative pose between device frame (anchored to a particular sensor defined by `origin_label`) and CPF (central pupil frame). `cpf_type` selects which CPF; see CpfType.
        """
    def get_transform_device_sensor(self, label: str, get_cad_value: bool = ...) -> SE3 | None:
        """
        returns calibrated `T_Device_Sensor` given a label. You can return the CAD extrinsics value by specifying `get_cad_value = True`.
        """
    def load_devignetting_mask(self, label: str) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
        """
        Load devignetting mask corresponding to the label and return as numpy array
        """
    def set_devignetting_mask_folder_path(self, mask_folder_path: str) -> None:
        """
        Set the devignetting mask folder path.
        """
class DeviceVersion:
    """
    A enum class that represents the version of the device: Gen1, Gen2.
    
    Members:
    
      NotValid
    
      Gen1
    
      Gen2
    """
    Gen1: typing.ClassVar[DeviceVersion]  # value = <DeviceVersion.Gen1: 1>
    Gen2: typing.ClassVar[DeviceVersion]  # value = <DeviceVersion.Gen2: 2>
    NotValid: typing.ClassVar[DeviceVersion]  # value = <DeviceVersion.NotValid: 0>
    __members__: typing.ClassVar[typing.Dict[str, DeviceVersion]]  # value = {'NotValid': <DeviceVersion.NotValid: 0>, 'Gen1': <DeviceVersion.Gen1: 1>, 'Gen2': <DeviceVersion.Gen2: 2>}
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    @typing.overload
    def __eq__(self, other: DeviceVersion) -> bool:
        ...
    @typing.overload
    def __eq__(self, other: object) -> bool:
        ...
    @typing.overload
    def __getstate__(self) -> int:
        ...
    @typing.overload
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    @typing.overload
    def __ne__(self, other: DeviceVersion) -> bool:
        ...
    @typing.overload
    def __ne__(self, other: object) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    @typing.overload
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @typing.overload
    def __setstate__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(arg0: DeviceVersion) -> int:
        ...
class ImuCalibration:
    """
    A class representing an IMU calibration model, including both accelerometer and gyroscope. We assume the accelerometer and gyroscope for each IMU are co-located and thus they share the same extrinsic.
    """
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    def __getstate__(self) -> tuple[str, typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"], SE3, float, float]:
        ...
    def __init__(self, label: str, rectification_matrix_accel: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 3]"], bias_accel: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"], rectification_matrix_gyro: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 3]"], bias_gyro: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"], T_device_imu: SE3, time_offset_sec_device_accel: typing.SupportsFloat | typing.SupportsIndex = ..., time_offset_sec_device_gyro: typing.SupportsFloat | typing.SupportsIndex = ...) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def get_accel_model(self) -> LinearRectificationModel3d:
        """
        Get accelerometer intrinsics model that contains rectification matrix and bias vector.
        """
    def get_gyro_model(self) -> LinearRectificationModel3d:
        """
        Get gyroscope intrinsics model that contains rectification matrix and bias vector.
        """
    def get_label(self) -> str:
        ...
    def get_time_offset_sec_device_accel(self) -> float:
        """
        Get time offset device to accelerometer, in seconds.
        """
    def get_time_offset_sec_device_gyro(self) -> float:
        """
        Get time offset device to gyroscope, in seconds.
        """
    def get_transform_device_imu(self) -> SE3:
        ...
    def raw_to_rectified_accel(self, raw: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        convert from imu sensor readout to actual acceleration: rectified = rectificationMatrix.inv() * (raw - bias).
        """
    def raw_to_rectified_gyro(self, raw: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        convert from imu sensor readout to actual angular velocity: rectified = rectificationMatrix.inv() * (raw - bias).
        """
    def rectified_to_raw_accel(self, rectified: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        simulate imu accel sensor readout from actual acceleration: raw = rectificationMatrix * rectified + bias.
        """
    def rectified_to_raw_gyro(self, rectified: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        simulate imu gyro sensor readout from actual angular velocity:  raw = rectificationMatrix * rectified + bias.
        """
class LinearRectificationModel3d:
    """
    A class that contains imu and mag intrinsics rectification model.
    """
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    def __getstate__(self) -> tuple[typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]]:
        ...
    def __init__(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 3]"], arg1: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> None:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def get_bias(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        Get the bias vector.
        """
    def get_rectification(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"]:
        """
        Get the rectification matrix. 
        """
class MagnetometerCalibration:
    """
    A class representing a magnetometer calibration model, including only the intrinsics of the magnetometer.
    """
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    def __getstate__(self) -> tuple[str, typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]]:
        ...
    def __init__(self, arg0: str, arg1: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 3]"], arg2: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> None:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def get_label(self) -> str:
        ...
    def get_model(self) -> LinearRectificationModel3d:
        """
        Get magnetometer intrinsics model.
        """
    def raw_to_rectified(self, raw: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        convert from mag sensor readout to actual magnetic field, rectified = rectificationMatrix.inv() * (raw - bias).
        """
    def rectified_to_raw(self, rectified: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        simulate mag sensor readout from actual magnetic field raw = rectificationMatrix * rectified + bias.
        """
class MicrophoneCalibration:
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    def __getstate__(self) -> tuple[str, float]:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: str, arg1: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def get_d_sensitivity_1k_dbv(self) -> float:
        ...
    def get_label(self) -> str:
        ...
    def raw_to_rectified(self, raw: typing.SupportsFloat | typing.SupportsIndex) -> float:
        ...
    def rectified_to_raw(self, rectified: typing.SupportsFloat | typing.SupportsIndex) -> float:
        ...
class NeuralBandBatchCalibration:
    """
    Container bundling the EMG + IMU calibrations that live on a single NeuralBand batch stream.
    """
    emg_calib: projectaria_tools.core.calibration.NeuralBandEmgCalibration | None
    imu_calib: projectaria_tools.core.calibration.NeuralBandImuCalibration | None
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    def __init__(self) -> None:
        ...
class NeuralBandEmgCalibration:
    """
    Wristband EMG calibration; converts raw ADC counts to voltage at the electrode input.
    """
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    @staticmethod
    def from_params_json(json: str, label: str = ...) -> projectaria_tools.core.calibration.NeuralBandEmgCalibration | None:
        """
        Parse the verbatim device.emg_calibration JSON blob from the CONFIG record.
        """
    def __getstate__(self) -> tuple[str, float, int, float, float, float, bool, int, int, int]:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: str, arg1: typing.SupportsFloat | typing.SupportsIndex, arg2: typing.SupportsInt | typing.SupportsIndex, arg3: typing.SupportsFloat | typing.SupportsIndex, arg4: typing.SupportsFloat | typing.SupportsIndex, arg5: typing.SupportsFloat | typing.SupportsIndex, arg6: bool, arg7: typing.SupportsInt | typing.SupportsIndex, arg8: typing.SupportsInt | typing.SupportsIndex, arg9: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    @typing.overload
    def adc_to_volts(self, adc_count: typing.SupportsInt | typing.SupportsIndex) -> float:
        """
        Convert one ADC count to voltage (V) at the electrode input.
        """
    @typing.overload
    def adc_to_volts(self, adc_counts: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> list[float]:
        """
        Convert a channel-value batch (typically NeuralBandEmgSample.channel_values) to voltage (V).
        """
    def get_adc_chip_code(self) -> int:
        """
        Opaque ADC front-end identifier; 0 means unknown, other codes are hardware-specific.
        """
    def get_adc_count_levels(self) -> int:
        ...
    def get_adc_vref_dc(self) -> float:
        ...
    def get_adc_vref_neg(self) -> float:
        ...
    def get_adc_vref_pos(self) -> float:
        ...
    def get_analog_gain(self) -> float:
        ...
    def get_dropped_lsb(self) -> int:
        ...
    def get_label(self) -> str:
        ...
    def get_streamed_bit_width(self) -> int:
        ...
    def is_truncated(self) -> bool:
        ...
    def volts_to_adc(self, volts: typing.SupportsFloat | typing.SupportsIndex) -> int:
        """
        Round-to-nearest inverse of adc_to_volts; returns an ADC count.
        """
class NeuralBandImuCalibration:
    """
    Wristband IMU (accel + gyro) calibration; parsed from the CONFIG record.
    """
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    @staticmethod
    def from_params_json(json: str, label: str = ...) -> projectaria_tools.core.calibration.NeuralBandImuCalibration | None:
        """
        Parse the verbatim CONFIG-record JSON blob (same blob that carries EMG calibration).
        """
    def __init__(self) -> None:
        ...
    def get_accel_cross_axis_rect_matrix(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"]:
        ...
    def get_accel_scaling_factor(self) -> float:
        """
        Wire accel scaling factor (g/LSB).
        """
    def get_calibration_applied(self) -> NeuralBandImuCalibrationApplied:
        ...
    def get_gyro_cross_axis_rect_matrix(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"]:
        ...
    def get_gyro_linear_g_rect_matrix(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"]:
        ...
    def get_gyro_scaling_factor(self) -> float:
        """
        Wire gyro scaling factor (dps/LSB).
        """
    def get_label(self) -> str:
        ...
    def get_offline_accel_offset_g(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        ...
    def get_offline_gyro_offset_dps(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        ...
    def get_online_accel_offset_g(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        ...
    def get_online_gyro_offset_dps(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        ...
    def get_sigfigs(self) -> int:
        ...
    def raw_to_rectified_accel(self, accel_m_sec2: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        Subtract the online accel bias (if firmware has not already) to yield rectified m/s².
        """
    def raw_to_rectified_gyro(self, gyro_rad_sec: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        Subtract the online gyro bias (if firmware has not already) to yield rectified rad/s.
        """
    def rectified_to_raw_accel(self, rectified_m_sec2: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        Inverse of raw_to_rectified_accel.
        """
    def rectified_to_raw_gyro(self, rectified_rad_sec: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        Inverse of raw_to_rectified_gyro.
        """
class NeuralBandImuCalibrationApplied:
    """
    Members:
    
      UNCALIBRATED
    
      CALIBRATED_ALL
    
      GYRO_ONLINE_BIAS
    
      ONLINE_BIAS
    """
    CALIBRATED_ALL: typing.ClassVar[NeuralBandImuCalibrationApplied]  # value = <NeuralBandImuCalibrationApplied.CALIBRATED_ALL: 1>
    GYRO_ONLINE_BIAS: typing.ClassVar[NeuralBandImuCalibrationApplied]  # value = <NeuralBandImuCalibrationApplied.GYRO_ONLINE_BIAS: 2>
    ONLINE_BIAS: typing.ClassVar[NeuralBandImuCalibrationApplied]  # value = <NeuralBandImuCalibrationApplied.ONLINE_BIAS: 3>
    UNCALIBRATED: typing.ClassVar[NeuralBandImuCalibrationApplied]  # value = <NeuralBandImuCalibrationApplied.UNCALIBRATED: 0>
    __members__: typing.ClassVar[typing.Dict[str, NeuralBandImuCalibrationApplied]]  # value = {'UNCALIBRATED': <NeuralBandImuCalibrationApplied.UNCALIBRATED: 0>, 'CALIBRATED_ALL': <NeuralBandImuCalibrationApplied.CALIBRATED_ALL: 1>, 'GYRO_ONLINE_BIAS': <NeuralBandImuCalibrationApplied.GYRO_ONLINE_BIAS: 2>, 'ONLINE_BIAS': <NeuralBandImuCalibrationApplied.ONLINE_BIAS: 3>}
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    @typing.overload
    def __eq__(self, other: NeuralBandImuCalibrationApplied) -> bool:
        ...
    @typing.overload
    def __eq__(self, other: object) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    @typing.overload
    def __ne__(self, other: NeuralBandImuCalibrationApplied) -> bool:
        ...
    @typing.overload
    def __ne__(self, other: object) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(arg0: NeuralBandImuCalibrationApplied) -> int:
        ...
class SensorCalibration:
    """
    An adaptor class to access an arbitrary sensor's calibration, which is a python `enum` of {CameraCalibration, ImuCalibration, MagnetometerCalibration, BarometerCalibration, MicrophoneCalibration, AriaEtCalibration, AriaMicCalibration}
    """
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    def __getstate__(self) -> tuple:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: None | projectaria_tools.core.calibration.CameraCalibration | projectaria_tools.core.calibration.ImuCalibration | projectaria_tools.core.calibration.MagnetometerCalibration | projectaria_tools.core.calibration.BarometerCalibration | projectaria_tools.core.calibration.MicrophoneCalibration | typing.Annotated[collections.abc.Sequence[CameraCalibration], "FixedSize(2)"] | typing.Annotated[collections.abc.Sequence[MicrophoneCalibration], "FixedSize(7)"] | projectaria_tools.core.calibration.NeuralBandBatchCalibration) -> None:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def aria_et_calibration(self) -> typing.Annotated[list[CameraCalibration], "FixedSize(2)"]:
        """
        Try to get the SensorCalibration as a AriaEtCalibration. Will throw if sensor type does not match.
        """
    def aria_mic_calibration(self) -> typing.Annotated[list[MicrophoneCalibration], "FixedSize(7)"]:
        """
        Try to get the SensorCalibration as a AriaMicCalibration. Will throw if sensor type does not match.
        """
    def barometer_calibration(self) -> BarometerCalibration:
        """
        Try to get the SensorCalibration as a BarometerCalibration. Will throw if sensor type does not match.
        """
    def camera_calibration(self) -> CameraCalibration:
        """
        Try to get the SensorCalibration as a CameraCalibration. Will throw if sensor type does not match.
        """
    def imu_calibration(self) -> ImuCalibration:
        """
        Try to get the SensorCalibration as a ImuCalibration. Will throw if sensor type does not match.
        """
    def magnetometer_calibration(self) -> MagnetometerCalibration:
        """
        Try to get the SensorCalibration as a MagnetometerCalibration. Will throw if sensor type does not match.
        """
    def microphone_calibration(self) -> MicrophoneCalibration:
        """
        Try to get the SensorCalibration as a MicrophoneCalibration. Will throw if sensor type does not match.
        """
    def neural_band_batch_calibration(self) -> NeuralBandBatchCalibration:
        """
        Try to get the SensorCalibration as a NeuralBandBatchCalibration (bundles EMG + IMU). Will throw if sensor type does not match.
        """
    def sensor_calibration_type(self) -> SensorCalibrationType:
        """
        get the type of this sensor calibration as an enum.
        """
class SensorCalibrationType:
    """
    Members:
    
      NOT_VALID
    
      CAMERA_CALIBRATION
    
      IMU_CALIBRATION
    
      MAGNETOMETER_CALIBRATION
    
      BAROMETER_CALIBRATION
    
      MICROPHONE_CALIBRATION
    
      ARIA_ET_CALIBRATION
    
      ARIA_MIC_CALIBRATION
    
      NEURAL_BAND_BATCH_CALIBRATION
    """
    ARIA_ET_CALIBRATION: typing.ClassVar[SensorCalibrationType]  # value = <SensorCalibrationType.ARIA_ET_CALIBRATION: 6>
    ARIA_MIC_CALIBRATION: typing.ClassVar[SensorCalibrationType]  # value = <SensorCalibrationType.ARIA_MIC_CALIBRATION: 7>
    BAROMETER_CALIBRATION: typing.ClassVar[SensorCalibrationType]  # value = <SensorCalibrationType.BAROMETER_CALIBRATION: 4>
    CAMERA_CALIBRATION: typing.ClassVar[SensorCalibrationType]  # value = <SensorCalibrationType.CAMERA_CALIBRATION: 1>
    IMU_CALIBRATION: typing.ClassVar[SensorCalibrationType]  # value = <SensorCalibrationType.IMU_CALIBRATION: 2>
    MAGNETOMETER_CALIBRATION: typing.ClassVar[SensorCalibrationType]  # value = <SensorCalibrationType.MAGNETOMETER_CALIBRATION: 3>
    MICROPHONE_CALIBRATION: typing.ClassVar[SensorCalibrationType]  # value = <SensorCalibrationType.MICROPHONE_CALIBRATION: 5>
    NEURAL_BAND_BATCH_CALIBRATION: typing.ClassVar[SensorCalibrationType]  # value = <SensorCalibrationType.NEURAL_BAND_BATCH_CALIBRATION: 8>
    NOT_VALID: typing.ClassVar[SensorCalibrationType]  # value = <SensorCalibrationType.NOT_VALID: 0>
    __members__: typing.ClassVar[typing.Dict[str, SensorCalibrationType]]  # value = {'NOT_VALID': <SensorCalibrationType.NOT_VALID: 0>, 'CAMERA_CALIBRATION': <SensorCalibrationType.CAMERA_CALIBRATION: 1>, 'IMU_CALIBRATION': <SensorCalibrationType.IMU_CALIBRATION: 2>, 'MAGNETOMETER_CALIBRATION': <SensorCalibrationType.MAGNETOMETER_CALIBRATION: 3>, 'BAROMETER_CALIBRATION': <SensorCalibrationType.BAROMETER_CALIBRATION: 4>, 'MICROPHONE_CALIBRATION': <SensorCalibrationType.MICROPHONE_CALIBRATION: 5>, 'ARIA_ET_CALIBRATION': <SensorCalibrationType.ARIA_ET_CALIBRATION: 6>, 'ARIA_MIC_CALIBRATION': <SensorCalibrationType.ARIA_MIC_CALIBRATION: 7>, 'NEURAL_BAND_BATCH_CALIBRATION': <SensorCalibrationType.NEURAL_BAND_BATCH_CALIBRATION: 8>}
    @staticmethod
    def _pybind11_conduit_v1_(*args, **kwargs):
        ...
    @typing.overload
    def __eq__(self, other: SensorCalibrationType) -> bool:
        ...
    @typing.overload
    def __eq__(self, other: object) -> bool:
        ...
    @typing.overload
    def __getstate__(self) -> int:
        ...
    @typing.overload
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    @typing.overload
    def __ne__(self, other: SensorCalibrationType) -> bool:
        ...
    @typing.overload
    def __ne__(self, other: object) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    @typing.overload
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @typing.overload
    def __setstate__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(arg0: SensorCalibrationType) -> int:
        ...
@typing.overload
def color_correct(src_image: typing.Annotated[numpy.typing.ArrayLike, numpy.uint8], device_version: DeviceVersion) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Correct color distorted image in old Aria recordings
    """
@typing.overload
def color_correct(src_image: typing.Annotated[numpy.typing.ArrayLike, numpy.uint16], device_version: DeviceVersion) -> None:
    """
    Correct color distorted image in old Aria recordings
    """
@typing.overload
def color_correct(src_image: typing.Annotated[numpy.typing.ArrayLike, numpy.uint64], device_version: DeviceVersion) -> None:
    """
    Correct color distorted image in old Aria recordings
    """
@typing.overload
def color_correct(src_image: typing.Annotated[numpy.typing.ArrayLike, numpy.float32], device_version: DeviceVersion) -> None:
    """
    Correct color distorted image in old Aria recordings
    """
def device_calibration_from_json(arg0: str) -> projectaria_tools.core.calibration.DeviceCalibration | None:
    """
    Load calibration from json.
    """
def device_calibration_from_json_string(arg0: str) -> projectaria_tools.core.calibration.DeviceCalibration | None:
    """
    Load calibration from json string.
    """
def device_calibration_to_json_string(arg0: DeviceCalibration) -> str:
    """
    Export device calibration to json string
    """
@typing.overload
def devignetting(src_image: typing.Annotated[numpy.typing.ArrayLike, numpy.uint8], devignetting_mask: typing.Annotated[numpy.typing.ArrayLike, numpy.float32]) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Devignetting image with devignetting mask
    """
@typing.overload
def devignetting(src_image: typing.Annotated[numpy.typing.ArrayLike, numpy.uint16], devignetting_mask: typing.Annotated[numpy.typing.ArrayLike, numpy.float32]) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Devignetting image with devignetting mask
    """
@typing.overload
def devignetting(src_image: typing.Annotated[numpy.typing.ArrayLike, numpy.uint64], devignetting_mask: typing.Annotated[numpy.typing.ArrayLike, numpy.float32]) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Devignetting image with devignetting mask
    """
@typing.overload
def devignetting(src_image: typing.Annotated[numpy.typing.ArrayLike, numpy.float32], devignetting_mask: typing.Annotated[numpy.typing.ArrayLike, numpy.float32]) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Devignetting image with devignetting mask
    """
@typing.overload
def distort_by_calibration(arraySrc: typing.Annotated[numpy.typing.ArrayLike, numpy.uint8], dstCalib: CameraCalibration, srcCalib: CameraCalibration, method: projectaria_tools.core.image.InterpolationMethod = ...) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input image to swap its underlying image distortion model.
    """
@typing.overload
def distort_by_calibration(arraySrc: typing.Annotated[numpy.typing.ArrayLike, numpy.float32], dstCalib: CameraCalibration, srcCalib: CameraCalibration, method: projectaria_tools.core.image.InterpolationMethod = ...) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input image to swap its underlying image distortion model.
    """
@typing.overload
def distort_by_calibration(arraySrc: typing.Annotated[numpy.typing.ArrayLike, numpy.uint16], dstCalib: CameraCalibration, srcCalib: CameraCalibration, method: projectaria_tools.core.image.InterpolationMethod = ...) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input image to swap its underlying image distortion model.
    """
@typing.overload
def distort_by_calibration(arraySrc: typing.Annotated[numpy.typing.ArrayLike, numpy.uint64], dstCalib: CameraCalibration, srcCalib: CameraCalibration, method: projectaria_tools.core.image.InterpolationMethod = ...) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input image to swap its underlying image distortion model.
    """
@typing.overload
def distort_by_calibration_and_apply_rotation(arraySrc: typing.Annotated[numpy.typing.ArrayLike, numpy.uint8], dstCalib: CameraCalibration, srcCalib: CameraCalibration, so3_srcCalib_dstCalib: SO3, method: projectaria_tools.core.image.InterpolationMethod = ...) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input image to swap its underlying image distortion model, while applying a rotation to the camera ray. This can be used for stereo rectification.
    """
@typing.overload
def distort_by_calibration_and_apply_rotation(arraySrc: typing.Annotated[numpy.typing.ArrayLike, numpy.float32], dstCalib: CameraCalibration, srcCalib: CameraCalibration, so3_srcCalib_dstCalib: SO3, method: projectaria_tools.core.image.InterpolationMethod = ...) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input image to swap its underlying image distortion model, while applying a rotation to the camera ray. This can be used for stereo rectification.
    """
@typing.overload
def distort_by_calibration_and_apply_rotation(arraySrc: typing.Annotated[numpy.typing.ArrayLike, numpy.uint16], dstCalib: CameraCalibration, srcCalib: CameraCalibration, so3_srcCalib_dstCalib: SO3, method: projectaria_tools.core.image.InterpolationMethod = ...) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input image to swap its underlying image distortion model, while applying a rotation to the camera ray. This can be used for stereo rectification.
    """
@typing.overload
def distort_by_calibration_and_apply_rotation(arraySrc: typing.Annotated[numpy.typing.ArrayLike, numpy.uint64], dstCalib: CameraCalibration, srcCalib: CameraCalibration, so3_srcCalib_dstCalib: SO3, method: projectaria_tools.core.image.InterpolationMethod = ...) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input image to swap its underlying image distortion model, while applying a rotation to the camera ray. This can be used for stereo rectification.
    """
@typing.overload
def distort_depth_by_calibration(arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.uint8], arg1: CameraCalibration, arg2: CameraCalibration) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input depth image using InterpolationMethod::Bilinear to swap its underlying image distortion model.
    """
@typing.overload
def distort_depth_by_calibration(arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float32], arg1: CameraCalibration, arg2: CameraCalibration) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input depth image using InterpolationMethod::Bilinear to swap its underlying image distortion model.
    """
@typing.overload
def distort_depth_by_calibration(arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.uint16], arg1: CameraCalibration, arg2: CameraCalibration) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input depth image using InterpolationMethod::Bilinear to swap its underlying image distortion model.
    """
@typing.overload
def distort_depth_by_calibration(arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.uint64], arg1: CameraCalibration, arg2: CameraCalibration) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input depth image using InterpolationMethod::Bilinear to swap its underlying image distortion model.
    """
@typing.overload
def distort_label_by_calibration(arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.uint8], arg1: CameraCalibration, arg2: CameraCalibration) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input image label using InterpolationMethod::NearestNeighbor to swap its underlying image distortion model.
    """
@typing.overload
def distort_label_by_calibration(arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float32], arg1: CameraCalibration, arg2: CameraCalibration) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input image label using InterpolationMethod::NearestNeighbor to swap its underlying image distortion model.
    """
@typing.overload
def distort_label_by_calibration(arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.uint16], arg1: CameraCalibration, arg2: CameraCalibration) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input image label using InterpolationMethod::NearestNeighbor to swap its underlying image distortion model.
    """
@typing.overload
def distort_label_by_calibration(arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.uint64], arg1: CameraCalibration, arg2: CameraCalibration) -> numpy.typing.NDArray[numpy.float32] | numpy.typing.NDArray[numpy.uint8] | numpy.typing.NDArray[numpy.uint16] | numpy.typing.NDArray[numpy.uint64] | numpy.typing.NDArray[...]:
    """
    Distorts an input image label using InterpolationMethod::NearestNeighbor to swap its underlying image distortion model.
    """
def from_device_class_name(name: str) -> DeviceVersion:
    """
    Get the device version from a class name in calibration
    """
def get_linear_camera_calibration(image_width: typing.SupportsInt | typing.SupportsIndex, image_height: typing.SupportsInt | typing.SupportsIndex, focal_length: typing.SupportsFloat | typing.SupportsIndex, label: str = ..., T_Device_Camera: SE3 = ..., time_offset_sec_device_camera: typing.SupportsFloat | typing.SupportsIndex = ...) -> CameraCalibration:
    """
    Function to create a simple Linear camera calibration object from some parameters.
    """
def get_name(deviceVersion: DeviceVersion) -> str:
    """
    Get the name from device version
    """
def get_spherical_camera_calibration(image_width: typing.SupportsInt | typing.SupportsIndex, image_height: typing.SupportsInt | typing.SupportsIndex, focal_length: typing.SupportsFloat | typing.SupportsIndex, label: str = ..., T_Device_Camera: SE3 = ..., time_offset_sec_device_camera: typing.SupportsFloat | typing.SupportsIndex = ...) -> CameraCalibration:
    """
    Function to create a simple Spherical camera calibration object from some parameters.
    """
def rescale_camera_calibration(camera_calibration: CameraCalibration, new_resolution: typing.Annotated[numpy.typing.ArrayLike, numpy.int32, "[2, 1]"], device_version: DeviceVersion, canonical_camera_label: str | None = ...) -> CameraCalibration:
    """
    Rescale an Aria camera calibration using the canonical device transform.
    """
def rotate_camera_calib_cw90deg(camera_calibration: CameraCalibration) -> CameraCalibration:
    """
    Rotate CameraCalibration (Linear model only) clock-wise for 90 degrees (Upright view)
    """
ARIA_ET_CALIBRATION: SensorCalibrationType  # value = <SensorCalibrationType.ARIA_ET_CALIBRATION: 6>
ARIA_MIC_CALIBRATION: SensorCalibrationType  # value = <SensorCalibrationType.ARIA_MIC_CALIBRATION: 7>
BAROMETER_CALIBRATION: SensorCalibrationType  # value = <SensorCalibrationType.BAROMETER_CALIBRATION: 4>
CALIBRATED_ALL: NeuralBandImuCalibrationApplied  # value = <NeuralBandImuCalibrationApplied.CALIBRATED_ALL: 1>
CAMERA_CALIBRATION: SensorCalibrationType  # value = <SensorCalibrationType.CAMERA_CALIBRATION: 1>
FISHEYE62: CameraModelType  # value = <CameraModelType.FISHEYE62: 4>
FISHEYE624: CameraModelType  # value = <CameraModelType.FISHEYE624: 3>
GYRO_ONLINE_BIAS: NeuralBandImuCalibrationApplied  # value = <NeuralBandImuCalibrationApplied.GYRO_ONLINE_BIAS: 2>
Gen1: DeviceVersion  # value = <DeviceVersion.Gen1: 1>
Gen2: DeviceVersion  # value = <DeviceVersion.Gen2: 2>
IMU_CALIBRATION: SensorCalibrationType  # value = <SensorCalibrationType.IMU_CALIBRATION: 2>
KANNALA_BRANDT_K3: CameraModelType  # value = <CameraModelType.KANNALA_BRANDT_K3: 2>
LINEAR: CameraModelType  # value = <CameraModelType.LINEAR: 0>
MAGNETOMETER_CALIBRATION: SensorCalibrationType  # value = <SensorCalibrationType.MAGNETOMETER_CALIBRATION: 3>
MICROPHONE_CALIBRATION: SensorCalibrationType  # value = <SensorCalibrationType.MICROPHONE_CALIBRATION: 5>
NEURAL_BAND_BATCH_CALIBRATION: SensorCalibrationType  # value = <SensorCalibrationType.NEURAL_BAND_BATCH_CALIBRATION: 8>
NOT_VALID: SensorCalibrationType  # value = <SensorCalibrationType.NOT_VALID: 0>
NotValid: DeviceVersion  # value = <DeviceVersion.NotValid: 0>
ONLINE_BIAS: NeuralBandImuCalibrationApplied  # value = <NeuralBandImuCalibrationApplied.ONLINE_BIAS: 3>
SPHERICAL: CameraModelType  # value = <CameraModelType.SPHERICAL: 1>
UNCALIBRATED: NeuralBandImuCalibrationApplied  # value = <NeuralBandImuCalibrationApplied.UNCALIBRATED: 0>
