/* Chronicle QA — answers questions strictly from stored observations.
   Everything is grounded in the world's event/entity memory. */

import {
  World, entityDef, zoneById, ENTITIES, MemEvent, fmtTs,
} from "./world";

export interface Citation {
  t: number;
  label: string;
  entityId?: string;
}

export interface Answer {
  text: string;
  grounded: boolean;
  citations: Citation[];
  highlight: string[];
}

const COLOR_WORDS: Record<string, string[]> = {
  red: ["red", "terracotta"],
  green: ["green", "olive", "leaf"],
  yellow: ["yellow", "mustard", "banana"],
  blue: ["blue"],
  white: ["white", "off-white", "cream"],
  black: ["black", "charcoal", "graphite", "grey", "gray"],
};

function lc(s: string) { return s.toLowerCase(); }

function findEntityInQuestion(q: string): string | null {
  const words = lc(q);
  // longest-label match first
  const sorted = [...ENTITIES].sort((a, b) => b.label.length - a.label.length);
  for (const def of sorted) {
    if (words.includes(def.label)) return def.id;
  }
  // aliases
  if (/\bbag\b/.test(words)) return "backpack";
  if (/\bfruit\b/.test(words)) return "apple";
  if (/\bcomputer\b/.test(words)) return "laptop";
  if (/\bmobile\b/.test(words)) return "phone";
  if (/\bpot\b|plant/.test(words)) return "plant";
  return null;
}

function findColorInQuestion(q: string): string | null {
  const words = lc(q);
  for (const [name, variants] of Object.entries(COLOR_WORDS)) {
    if (variants.some((v) => new RegExp(`\\b${v}\\b`).test(words))) return name;
  }
  return null;
}

function findZoneInQuestion(q: string): string | null {
  const words = lc(q);
  if (/counter|sink|kitchen/.test(words)) return "counter";
  if (/\btable\b|dining/.test(words)) return "table";
  if (/shelf/.test(words)) return "shelf";
  if (/floor|door/.test(words)) return "floor";
  return null;
}

function parseRange(q: string): [number, number] | null {
  const m = lc(q).match(/(\d{1,2}):(\d{2})\D+(\d{1,2}):(\d{2})/);
  if (m) return [parseInt(m[1]) * 60 + parseInt(m[2]), parseInt(m[3]) * 60 + parseInt(m[4])];
  return null;
}

function pick<T>(arr: T[], seed: number): T {
  return arr[Math.abs(seed) % arr.length];
}

function zonePhrase(zoneId: string, def: ReturnType<typeof entityDef>): string {
  const support = def.support[zoneId];
  if (support) return `on the ${support}`;
  return zoneById(zoneId).label;
}

function eventsFor(w: World, entityId: string): MemEvent[] {
  return w.events.filter((e) => e.entityId === entityId && e.kind !== "re-seen");
}

/* ---------------- the answer engine ---------------- */
export function answerQuestion(w: World, raw: string): Answer {
  const q = lc(raw.trim());
  const seed = raw.length + (w.events.length % 7);
  const seen = (id: string) => w.entities[id]?.firstSeen !== null;
  const label = (id: string) => entityDef(id).label;

  /* not watching yet */
  if (w.mode === "idle" || w.mode === "booting") {
    return {
      text: "I haven't opened my eyes yet — hit ▶ Run and give me a few seconds of video. After that I'll remember everything I saw, pinky promise.",
      grounded: false,
      citations: [],
      highlight: [],
    };
  }

  /* greetings & meta */
  if (/^(hi|hello|hey|yo|sup|hola)\b/.test(q) || /good (morning|evening|afternoon)/.test(q)) {
    return {
      text: pick([
        "Hey! I'm Chronicle — I've been watching the feed and taking tiny mental notes. Ask me where anything is.",
        "Hi hi. My head-cam's been rolling, so my memory of this kitchen is suspiciously good. What do you want to know?",
      ], seed),
      grounded: true,
      citations: [],
      highlight: [],
    };
  }
  if (/who are you|what are you|your name/.test(q)) {
    return {
      text: "I'm Chronicle — an episodic memory for a head-cam. I watch, I note objects, colours, places and little events (picked up, put down…), and later you ask me things. I only answer from what I actually saw, and I'll tell you when I don't know.",
      grounded: true,
      citations: [],
      highlight: [],
    };
  }
  if (/thank|thanks|thx/.test(q)) {
    return { text: pick(["Any time. I literally exist for this.", "You're welcome! My favourite kind of event: helping."], seed), grounded: true, citations: [], highlight: [] };
  }
  if (/joke|funny/.test(q)) {
    return {
      text: "Why did the mug get promoted? It was outstanding in its field of view. …I'll see myself out.",
      grounded: true, citations: [], highlight: [],
    };
  }

  const eid = findEntityInQuestion(q);
  const color = findColorInQuestion(q);
  const zone = findZoneInQuestion(q);
  const range = parseRange(q);

  /* "where was X before it was placed on ..." */
  if (eid && /\b(before|prior|earlier)\b/.test(q) && /placed|put|moved/.test(q)) {
    const st = w.entities[eid];
    if (!seen(eid)) return ungrounded(w, eid);
    const places = eventsFor(w, eid).filter((e) => e.kind === "place");
    const lastPlace = places[places.length - 1];
    if (lastPlace && lastPlace.from) {
      return {
        text: pick([
          `Before it landed on ${zoneById(lastPlace.to!).label}, the ${label(eid)} was ${zonePhrase(lastPlace.from, entityDef(eid))} — right up until ${fmtTs(lastPlace.t)}. I watched the whole trip.`,
          `Easy: it came from ${zonePhrase(lastPlace.from, entityDef(eid))}. It got placed on ${zoneById(lastPlace.to!).label} at ${fmtTs(lastPlace.t)}.`,
        ], seed),
        grounded: true,
        citations: [
          { t: lastPlace.t, label: `${label(eid)} placed`, entityId: eid },
          { t: Math.max(0, lastPlace.t - 3), label: `${label(eid)} before`, entityId: eid },
        ],
        highlight: [eid],
      };
    }
    return {
      text: `The ${label(eid)} hasn't been moved yet in what I watched — as far as I know it's always been ${zonePhrase(st.zone, entityDef(eid))}.`,
      grounded: true,
      citations: [{ t: st.firstSeen ?? 0, label: `${label(eid)} first seen`, entityId: eid }],
      highlight: [eid],
    };
  }

  /* where is / where was */
  if (eid && /\bwhere\b/.test(q)) {
    const st = w.entities[eid];
    if (!seen(eid)) return ungrounded(w, eid);
    const past = /\bwas\b/.test(q) && !/\bis\b/.test(q);
    if (past) {
      return {
        text: `The ${label(eid)} was last ${zonePhrase(st.zone, entityDef(eid))} — I had it in view around ${fmtTs(st.lastSeen ?? st.firstSeen ?? 0)}. Since then my camera's been pointed elsewhere, so that's my best honest answer.`,
        grounded: true,
        citations: [{ t: st.lastSeen ?? st.firstSeen ?? 0, label: `${label(eid)} last seen`, entityId: eid }],
        highlight: [eid],
      };
    }
    const since = fmtTs(st.zoneSince);
    const prev = st.prevZone && st.prevZone !== st.zone ? ` It got there from ${zoneById(st.prevZone).label} at ${since}.` : "";
    return {
      text: pick([
        `Right now the ${label(eid)} is ${zonePhrase(st.zone, entityDef(eid))} — it's been there since ${since}.${prev}`,
        `${cap(label(eid))}: ${zonePhrase(st.zone, entityDef(eid))}, since ${since}.${prev}`,
      ], seed),
      grounded: true,
      citations: [
        { t: st.lastSeen ?? 0, label: `${label(eid)} now`, entityId: eid },
        ...(prev ? [{ t: st.zoneSince, label: `${label(eid)} moved`, entityId: eid }] : []),
      ],
      highlight: [eid],
    };
  }

  /* what colour */
  if (eid && /(what|which).*(colour|color)|\bcolour\b|\bcolor\b/.test(q)) {
    const def = entityDef(eid);
    if (!seen(eid)) return ungrounded(w, eid);
    return {
      text: pick([
        `The ${def.label} is ${def.colorName}. ${def.texture.split(",")[0]} finish — I'm quite sure, I've stared at it a lot.`,
        `${cap(def.colorName)}. At least that's what my colour pass says about the ${def.label}, and it's been consistent every time I looked.`,
      ], seed),
      grounded: true,
      citations: [{ t: w.entities[eid].lastSeen ?? 0, label: `${def.label} appearance`, entityId: eid }],
      highlight: [eid],
    };
  }

  /* describe */
  if (eid && /\b(describe|tell me about|details|properties|what about)\b/.test(q)) {
    const def = entityDef(eid);
    const st = w.entities[eid];
    if (!seen(eid)) return ungrounded(w, eid);
    const support = def.support[st.zone];
    const container = def.container;
    const bits = [
      `colour: ${def.colorName}`,
      `shape: ${def.shape}`,
      `size: ${def.size}`,
      `texture: ${def.texture}`,
      `state: ${st.state}`,
      `${support ? `sitting on the ${support}` : "support: unknown"}`,
    ];
    if (container) bits.push(`in a ${container}`);
    return {
      text: `Here's my full note on the ${def.label} — ${bits.join(", ")}. First seen at ${fmtTs(st.firstSeen ?? 0)}, last looked at ${fmtTs(st.lastSeen ?? 0)}.`,
      grounded: true,
      citations: [
        { t: st.firstSeen ?? 0, label: `${def.label} first seen`, entityId: eid },
        { t: st.lastSeen ?? 0, label: `${def.label} last seen`, entityId: eid },
      ],
      highlight: [eid],
    };
  }

  /* what red objects / what X things did you see */
  if (color && /(objects|things|items|stuff|one|ones|object)/.test(q)) {
    const variants = COLOR_WORDS[color];
    const matches = ENTITIES.filter((def) => {
      if (!seen(def.id)) return false;
      const cn = lc(def.colorName);
      return variants.some((v) => cn.includes(v));
    });
    if (matches.length === 0) {
      return {
        text: `Hmm — I didn't spot any clearly ${color} thing in the feed. My palette so far: ${ENTITIES.filter(seen).map((d) => `${d.colorName} ${d.label}`).join(", ")}.`,
        grounded: false,
        citations: [],
        highlight: [],
      };
    }
    const list = matches.map((d) => {
      const st = w.entities[d.id];
      return `the ${d.label} (${zonePhrase(st.zone, d)})`;
    });
    return {
      text: `I spotted ${matches.length === 1 ? "one" : matches.length} ${color} ${matches.length === 1 ? "thing" : "things"}: ${list.join(" and ")}.`,
      grounded: true,
      citations: matches.map((d) => ({ t: w.entities[d.id].lastSeen ?? 0, label: `${d.label} seen`, entityId: d.id })),
      highlight: matches.map((d) => d.id),
    };
  }

  /* what's on / in a zone */
  if (zone && /(what|which|who).*(on|in|at|near)|list|show/.test(q)) {
    const here = ENTITIES.filter((d) => seen(d.id) && w.entities[d.id].zone === zone);
    if (here.length === 0) {
      return { text: `Nothing on ${zoneById(zone).label} right now — at least nothing I'd bet on.`, grounded: true, citations: [], highlight: [] };
    }
    return {
      text: `On ${zoneById(zone).label} I currently make out: ${here.map((d) => `the ${d.label}`).join(", ")}. ${here.length > 2 ? "Cosy." : ""}`,
      grounded: true,
      citations: here.map((d) => ({ t: w.entities[d.id].lastSeen ?? 0, label: `${d.label} on ${zoneById(zone).short}`, entityId: d.id })),
      highlight: here.map((d) => d.id),
    };
  }

  /* how many */
  if (/how many/.test(q)) {
    if (zone) {
      const here = ENTITIES.filter((d) => seen(d.id) && w.entities[d.id].zone === zone);
      return {
        text: `I count ${here.length} ${here.length === 1 ? "object" : "objects"} on ${zoneById(zone).label}: ${here.map((d) => d.label).join(", ") || "…"}.`,
        grounded: true,
        citations: here.slice(0, 3).map((d) => ({ t: w.entities[d.id].lastSeen ?? 0, label: d.label, entityId: d.id })),
        highlight: here.map((d) => d.id),
      };
    }
    if (eid) {
      const st = w.entities[eid];
      return { text: `There's exactly one ${label(eid)} — I've seen it ${st.seenCount} ${st.seenCount === 1 ? "time" : "times"}, same one each time.`, grounded: true, citations: [{ t: st.lastSeen ?? 0, label: label(eid), entityId: eid }], highlight: [eid] };
    }
    const all = ENTITIES.filter(seen);
    return {
      text: `So far I'm tracking ${all.length} distinct objects: ${all.map((d) => d.label).join(", ")}.`,
      grounded: true,
      citations: all.slice(0, 4).map((d) => ({ t: w.entities[d.id].firstSeen ?? 0, label: `${d.label} first seen`, entityId: d.id })),
      highlight: all.map((d) => d.id),
    };
  }

  /* when did ... */
  if (eid && /\bwhen\b/.test(q)) {
    if (!seen(eid)) return ungrounded(w, eid);
    const evs = eventsFor(w, eid).filter((e) => e.kind === "place" || e.kind === "state" || e.kind === "pick-up");
    if (evs.length > 0) {
      const lines = evs.map((e) => `• ${fmtTs(e.t)} — ${e.text}`);
      return {
        text: `Here's the ${label(eid)}'s little life story so far:\n${lines.join("\n")}`,
        grounded: true,
        citations: evs.map((e) => ({ t: e.t, label: `${label(eid)} ${e.kind}`, entityId: eid })),
        highlight: [eid],
      };
    }
    return {
      text: `The ${label(eid)} first showed up at ${fmtTs(w.entities[eid].firstSeen ?? 0)} and hasn't done anything dramatic since. Zen master.`,
      grounded: true,
      citations: [{ t: w.entities[eid].firstSeen ?? 0, label: `${label(eid)} first seen`, entityId: eid }],
      highlight: [eid],
    };
  }

  /* what happened (range) */
  if (/(what|anything).*(happen|occur|missed)|recap|summary|events/.test(q)) {
    const evs = w.events.filter((e) => {
      if (range) return e.t >= range[0] && e.t <= range[1];
      return true;
    });
    if (evs.length === 0) {
      return {
        text: range
          ? `Between ${fmtTs(range[0])} and ${fmtTs(range[1])} — quiet stretch, nothing worth a sticky note.`
          : "Nothing logged yet — my notebook is tragically empty.",
        grounded: true, citations: [], highlight: [],
      };
    }
    const slice = evs.slice(-5);
    const lines = slice.map((e) => `• ${fmtTs(e.t)} — ${e.text}`);
    return {
      text: `${range ? `Between ${fmtTs(range[0])} and ${fmtTs(range[1])}:` : "Recent memory, freshest last:"}\n${lines.join("\n")}`,
      grounded: true,
      citations: slice.slice(-3).map((e) => ({ t: e.t, label: e.text.slice(0, 24), entityId: e.entityId })),
      highlight: [...new Set(slice.map((e) => e.entityId))],
    };
  }

  /* mention of a known entity, any phrasing */
  if (eid) {
    const def = entityDef(eid);
    const st = w.entities[eid];
    if (!seen(eid)) return ungrounded(w, eid);
    return {
      text: `The ${def.label}? ${cap(def.colorName)}, ${def.shape}, currently ${st.state}, ${zonePhrase(st.zone, def)}. That's the gist — ask "describe the ${def.label}" for the whole card.`,
      grounded: true,
      citations: [{ t: st.lastSeen ?? 0, label: def.label, entityId: eid }],
      highlight: [eid],
    };
  }

  /* color-only question */
  if (color) {
    return {
      text: `I can search by colour if you point me at a type of thing — like "what red objects did you see?" Right now my world is: ${ENTITIES.filter(seen).map((d) => d.label).join(", ")}.`,
      grounded: false, citations: [], highlight: [],
    };
  }

  /* fallback: not grounded */
  return ungrounded(w, null);
}

function ungrounded(w: World, eid: string | null): Answer {
  const known = ENTITIES.filter((d) => w.entities[d.id].firstSeen !== null).map((d) => d.label);
  const about = eid ? `the ${entityDef(eid).label}` : "that";
  return {
    text: pick([
      `I've got no observation about ${about} — and I refuse to make things up. So far I've only seen: ${known.join(", ")}.`,
      `That one's outside my memory. My head-cam only knows ${known.join(", ")}. Ask me about one of those?`,
    ], known.length + 3),
    grounded: false,
    citations: [],
    highlight: [],
  };
}

function cap(s: string) { return s.charAt(0).toUpperCase() + s.slice(1); }
