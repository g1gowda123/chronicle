/* Chronicle — simulated egocentric world.
   A tiny scripted "morning in the kitchen" that the memory system watches.
   Pure TS: no canvas, no React. The renderer + hook consume it. */

export interface ZoneDef {
  id: string;
  label: string;
  short: string;
  roomX: number;
  depth: number;
}

export type EntityKind =
  | "mug" | "cup" | "bowl" | "apple" | "banana"
  | "book" | "laptop" | "phone" | "plant" | "backpack";

export interface EntityDef {
  id: string;
  label: string;
  kind: EntityKind;
  colorHex: string;
  colorName: string;
  shape: string;
  size: string;
  texture: string;
  brightness: string;
  slots: Record<string, number>; // zoneId -> room x anchor
  zone0: string;
  state0: string;
  conf: number;
  support: Record<string, string>; // zoneId -> support surface label
  container?: string; // fixed container, else derived from support
  unavailable?: string[]; // property names shown as "unavailable"
  state1?: string; // optional scripted later state
}

export const ZONES: ZoneDef[] = [
  { id: "counter", label: "the kitchen counter", short: "kitchen counter", roomX: 200, depth: 1.0 },
  { id: "table", label: "the dining table", short: "dining table", roomX: 745, depth: 1.14 },
  { id: "shelf", label: "the wall shelf", short: "wall shelf", roomX: 470, depth: 0.82 },
  { id: "floor", label: "the floor by the door", short: "floor by the door", roomX: 655, depth: 0.94 },
];

export const ENTITIES: EntityDef[] = [
  {
    id: "mug", label: "mug", kind: "mug",
    colorHex: "#c6553b", colorName: "terracotta red",
    shape: "cylinder", size: "palm-sized", texture: "matte", brightness: "warm, mid",
    slots: { counter: 128, table: 668 }, zone0: "counter", state0: "resting, empty",
    conf: 0.96, support: { counter: "kitchen counter", table: "dining table" },
  },
  {
    id: "cup", label: "cup", kind: "cup",
    colorHex: "#4e86a8", colorName: "ceramic blue",
    shape: "tapered cylinder", size: "small", texture: "glossy", brightness: "cool, mid",
    slots: { counter: 262, table: 762 }, zone0: "counter", state0: "resting, empty",
    conf: 0.94, support: { counter: "kitchen counter, next to the sink", table: "dining table" },
  },
  {
    id: "bowl", label: "bowl", kind: "bowl",
    colorHex: "#e9e0cb", colorName: "off-white",
    shape: "hemisphere", size: "small", texture: "glossy ceramic", brightness: "bright",
    slots: { counter: 86 }, zone0: "counter", state0: "resting, empty",
    conf: 0.91, support: { counter: "kitchen counter" },
  },
  {
    id: "apple", label: "apple", kind: "apple",
    colorHex: "#d93b2b", colorName: "bright red",
    shape: "sphere", size: "tiny", texture: "shiny", brightness: "bright highlight",
    slots: { table: 628, counter: 168 }, zone0: "table", state0: "resting, whole",
    conf: 0.95, support: { table: "dining table", counter: "kitchen counter, by the fruit bowl" },
  },
  {
    id: "banana", label: "banana", kind: "banana",
    colorHex: "#f2c14e", colorName: "banana yellow",
    shape: "crescent", size: "small", texture: "smooth peel", brightness: "bright",
    slots: { table: 822 }, zone0: "table", state0: "resting, ripe",
    conf: 0.62, support: { table: "dining table" },
  },
  {
    id: "book", label: "book", kind: "book",
    colorHex: "#d9a62e", colorName: "mustard yellow",
    shape: "flat rectangle", size: "novel-sized", texture: "paper, matte", brightness: "warm, mid",
    slots: { table: 796 }, zone0: "table", state0: "closed",
    conf: 0.93, support: { table: "dining table" },
    unavailable: ["container"],
  },
  {
    id: "laptop", label: "laptop", kind: "laptop",
    colorHex: "#4a4a48", colorName: "graphite grey",
    shape: "open wedge", size: "13-inch", texture: "brushed aluminium", brightness: "screen glow",
    slots: { table: 892 }, zone0: "table", state0: "closed, lid down",
    conf: 0.97, support: { table: "dining table" },
    unavailable: ["container"],
    state1: "open, screen on",
  },
  {
    id: "phone", label: "phone", kind: "phone",
    colorHex: "#2e2c28", colorName: "charcoal black",
    shape: "rounded slab", size: "pocket-sized", texture: "glass + matte rail", brightness: "dark",
    slots: { table: 598 }, zone0: "table", state0: "face-down",
    conf: 0.9, support: { table: "dining table" },
    unavailable: ["texture", "container"],
  },
  {
    id: "plant", label: "plant", kind: "plant",
    colorHex: "#4e9b5e", colorName: "leaf green",
    shape: "leafy clump", size: "medium", texture: "waxy leaves", brightness: "dappled",
    slots: { shelf: 470 }, zone0: "shelf", state0: "potted, thriving",
    conf: 0.98, support: { shelf: "wall shelf" },
    container: "terracotta pot",
  },
  {
    id: "backpack", label: "backpack", kind: "backpack",
    colorHex: "#7a7a46", colorName: "olive green",
    shape: "rounded box", size: "daypack", texture: "woven canvas", brightness: "matte, mid",
    slots: { floor: 655 }, zone0: "floor", state0: "zipped shut",
    conf: 0.95, support: { floor: "floor" },
    state1: "front pocket open",
  },
];

export const LOOP_LEN = 60; // seconds of scripted morning

export type MemKind = "first-seen" | "pick-up" | "place" | "state" | "re-seen";

export interface MemEvent {
  id: number;
  t: number;
  kind: MemKind;
  entityId: string;
  label: string;
  from?: string;
  to?: string;
  text: string;
  icon: string;
  conf?: number;
}

export interface VerifyItem {
  id: string;
  entityId: string;
  label: string;
  conf: number;
  t: number;
  status: "pending" | "confirmed" | "rejected";
}

export interface LogLine {
  t: number;
  level: "info" | "ok" | "warn";
  text: string;
}

export interface Ping {
  entityId: string;
  born: number;
  ttl: number;
}

export interface EntityState {
  id: string;
  zone: string;
  prevZone: string;
  zoneSince: number;
  roomX: number;
  held: boolean;
  state: string;
  stateSince: number;
  firstSeen: number | null;
  lastSeen: number | null;
  conf: number;
  seenCount: number;
}

export type Mode = "idle" | "booting" | "processing" | "ready" | "paused" | "error";

export interface World {
  mode: Mode;
  t: number;            // global clock since boot (s)
  loopT: number;        // position inside the scripted loop
  loop: number;
  rewinding: number;    // >0 while the loop glitch plays
  camX: number;
  camOverride: { targetX: number; until: number } | null;
  entities: Record<string, EntityState>;
  order: string[];
  events: MemEvent[];
  eventId: number;
  fired: Set<string>;
  log: LogLine[];
  verifications: VerifyItem[];
  metrics: { frames: number; fps: number; actions: number; transitions: number; detections: number };
  pings: Ping[];
  handWin: { start: number; end: number; carry: string; fromX: number; toX: number } | null;
  graphVersion: number;
  unglugged: boolean;
}

/* --------- camera keyframes (scripted pan path) --------- */
const CAM: Array<{ t: number; x: number }> = [
  { t: 0, x: 200 }, { t: 6, x: 218 }, { t: 9, x: 745 }, { t: 14, x: 762 },
  { t: 16.5, x: 470 }, { t: 18.5, x: 205 }, { t: 23.5, x: 715 }, { t: 27.5, x: 728 },
  { t: 29.5, x: 225 }, { t: 33, x: 742 }, { t: 37, x: 735 }, { t: 39.5, x: 660 },
  { t: 43, x: 205 }, { t: 47, x: 218 }, { t: 49, x: 760 }, { t: 52.5, x: 748 },
  { t: 56, x: 480 }, { t: 58.5, x: 240 }, { t: 60, x: 205 },
];

/* --------- scripted morning --------- */
type ScriptItem =
  | { t: number; kind: "detect"; id: string }
  | { t: number; kind: "pickup"; id: string; placeT: number; toZone: string }
  | { t: number; kind: "place"; id: string; zone: string; pickT: number }
  | { t: number; kind: "state"; id: string; state: string };

export const SCRIPT: ScriptItem[] = [
  { t: 0.8, kind: "detect", id: "mug" },
  { t: 1.6, kind: "detect", id: "cup" },
  { t: 2.6, kind: "detect", id: "bowl" },
  { t: 9.6, kind: "detect", id: "apple" },
  { t: 10.6, kind: "detect", id: "book" },
  { t: 11.6, kind: "detect", id: "laptop" },
  { t: 12.6, kind: "detect", id: "phone" },
  { t: 16.2, kind: "detect", id: "plant" },
  { t: 17.2, kind: "detect", id: "backpack" },

  { t: 19.6, kind: "pickup", id: "mug", placeT: 23.2, toZone: "table" },
  { t: 23.2, kind: "place", id: "mug", zone: "table", pickT: 19.6 },

  { t: 29.3, kind: "pickup", id: "cup", placeT: 32.6, toZone: "table" },
  { t: 32.6, kind: "place", id: "cup", zone: "table", pickT: 29.3 },

  { t: 34.4, kind: "detect", id: "banana" },

  { t: 39.4, kind: "pickup", id: "apple", placeT: 42.8, toZone: "counter" },
  { t: 42.8, kind: "place", id: "apple", zone: "counter", pickT: 39.4 },

  { t: 49.4, kind: "state", id: "laptop", state: "open, screen on" },
  { t: 51.5, kind: "state", id: "backpack", state: "front pocket open" },
];

export function zoneById(id: string): ZoneDef {
  return ZONES.find((z) => z.id === id) ?? ZONES[0];
}

export function entityDef(id: string): EntityDef {
  return ENTITIES.find((e) => e.id === id) ?? ENTITIES[0];
}

export function fmtT(t: number): string {
  const s = Math.max(0, t);
  const m = Math.floor(s / 60);
  const ss = Math.floor(s % 60);
  const d = Math.floor((s % 1) * 10);
  return `${String(m).padStart(2, "0")}:${String(ss).padStart(2, "0")}.${d}`;
}

export function fmtTs(t: number): string {
  const s = Math.max(0, t);
  const m = Math.floor(s / 60);
  const ss = Math.floor(s % 60);
  return `${String(m).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}

/* ---------- camera interpolation ---------- */
function camScriptX(loopT: number): number {
  for (let i = 0; i < CAM.length - 1; i++) {
    const a = CAM[i], b = CAM[i + 1];
    if (loopT >= a.t && loopT <= b.t) {
      const span = b.t - a.t || 1;
      const k = (loopT - a.t) / span;
      const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2; // easeInOut
      return a.x + (b.x - a.x) * e;
    }
  }
  return 205;
}

/* ---------- world creation ---------- */
export function createWorld(): World {
  const entities: Record<string, EntityState> = {};
  const order: string[] = [];
  for (const def of ENTITIES) {
    entities[def.id] = {
      id: def.id,
      zone: def.zone0,
      prevZone: def.zone0,
      zoneSince: 0,
      roomX: def.slots[def.zone0] ?? 300,
      held: false,
      state: def.state0,
      stateSince: 0,
      firstSeen: null,
      lastSeen: null,
      conf: 0,
      seenCount: 0,
    };
    order.push(def.id);
  }
  return {
    mode: "idle",
    t: 0,
    loopT: 0,
    loop: 0,
    rewinding: 0,
    camX: 205,
    camOverride: null,
    entities,
    order,
    events: [],
    eventId: 0,
    fired: new Set(),
    log: [],
    verifications: [],
    metrics: { frames: 0, fps: 0, actions: 0, transitions: 0, detections: 0 },
    pings: [],
    handWin: null,
    graphVersion: 0,
    unglugged: false,
  };
}

function pushLog(w: World, level: LogLine["level"], text: string) {
  w.log.push({ t: w.t, level, text });
  if (w.log.length > 90) w.log.splice(0, w.log.length - 90);
}

function pushEvent(w: World, e: Omit<MemEvent, "id">) {
  w.events.push({ ...e, id: ++w.eventId });
  if (w.events.length > 120) w.events.splice(0, w.events.length - 120);
  w.graphVersion++;
}

export function pingEntity(w: World, id: string) {
  w.pings.push({ entityId: id, born: w.t, ttl: 2.4 });
  if (w.pings.length > 6) w.pings.shift();
}

/* ---------- step ---------- */
export function stepWorld(w: World, dt: number) {
  // decay pings regardless of mode
  for (const p of w.pings) p.ttl -= dt;
  w.pings = w.pings.filter((p) => p.ttl > 0);
  if (w.rewinding > 0) w.rewinding -= dt;

  if (w.mode !== "processing" && w.mode !== "ready") return;

  const prevLoopT = w.loopT;
  w.t += dt;
  w.loopT += dt;

  if (w.loopT >= LOOP_LEN) {
    w.loopT -= LOOP_LEN;
    w.loop++;
    w.rewinding = 0.9;
    w.fired.clear();
    // physical reset: entities go home (memory keeps everything)
    for (const def of ENTITIES) {
      const st = w.entities[def.id];
      if (!st.held) {
        st.zone = def.zone0;
        st.prevZone = def.zone0;
        st.zoneSince = w.t;
        st.state = def.state0;
        st.stateSince = w.t;
      }
      st.held = false;
    }
    w.handWin = null;
    pushLog(w, "info", "re-walking the scene — memory stays put");
  }

  /* camera */
  if (w.camOverride) {
    if (w.t > w.camOverride.until) {
      w.camOverride = null;
    } else {
      w.camX += (w.camOverride.targetX - w.camX) * Math.min(1, dt * 3.2);
    }
  }
  if (!w.camOverride) {
    const target = camScriptX(w.loopT);
    w.camX += (target - w.camX) * Math.min(1, dt * 2.4);
  }

  /* scripted events */
  for (const item of SCRIPT) {
    const key = `${w.loop}:${item.kind}:${item.id}:${item.t}`;
    const crossed = prevLoopT < item.t && w.loopT >= item.t;
    if (!crossed || w.fired.has(key)) continue;
    w.fired.add(key);
    const st = w.entities[item.id];
    const def = entityDef(item.id);

    if (item.kind === "detect") {
      st.conf = def.conf;
      st.seenCount++;
      const first = st.firstSeen === null;
      st.firstSeen ??= w.t;
      st.lastSeen = w.t;
      if (st.zone !== def.zone0 && !st.held) {
        // re-detected at home zone after loop reset
        st.zone = def.zone0;
        st.roomX = def.slots[def.zone0] ?? st.roomX;
      }
      w.metrics.detections++;
      if (first) {
        pushEvent(w, {
          t: w.t, kind: "first-seen", entityId: def.id, label: def.label,
          to: st.zone, icon: "eye",
          text: `first saw the ${def.label} ${zoneById(st.zone).label}`,
          conf: def.conf,
        });
        pushLog(w, "ok", `new entity → ${def.label} (${zoneById(st.zone).short}) @ ${fmtTs(w.t)}`);
      } else {
        st.lastSeen = w.t;
        if (w.loop > 0) pushLog(w, "info", `re-confirmed ${def.label} — same ${def.label}, promise`);
      }
      if (def.conf < 0.7) {
        const vid = `${w.loop}-${def.id}`;
        if (!w.verifications.some((v) => v.id === vid)) {
          w.verifications.push({
            id: vid, entityId: def.id, label: def.label, conf: def.conf, t: w.t, status: "pending",
          });
          pushLog(w, "warn", `low confidence on "${def.label}" (${Math.round(def.conf * 100)}%) — queued for human check`);
        }
      }
    }

    if (item.kind === "pickup") {
      st.held = true;
      st.prevZone = st.zone;
      st.state = "being carried";
      st.stateSince = w.t;
      st.lastSeen = w.t;
      w.handWin = {
        start: item.t - 0.35,
        end: item.placeT + 0.35,
        carry: item.id,
        fromX: def.slots[st.zone] ?? st.roomX,
        toX: def.slots[item.toZone] ?? st.roomX,
      };
      w.metrics.actions++;
      pushEvent(w, {
        t: w.t, kind: "pick-up", entityId: def.id, label: def.label,
        from: st.zone, icon: "up",
        text: `picked up the ${def.label} from ${zoneById(st.zone).label}`,
      });
      pushLog(w, "info", `action → pick_up(${def.label}) @ ${fmtTs(w.t)}`);
    }

    if (item.kind === "place") {
      st.held = false;
      const from = st.zone;
      st.zone = item.zone;
      st.prevZone = from;
      st.zoneSince = w.t;
      const d = entityDef(item.id);
      st.state = item.zone === d.zone0 ? d.state0 : d.state0.replace("resting", "placed, resting");
      st.stateSince = w.t;
      st.lastSeen = w.t;
      st.roomX = d.slots[item.zone] ?? st.roomX;
      w.metrics.actions++;
      w.metrics.transitions++;
      pushEvent(w, {
        t: w.t, kind: "place", entityId: def.id, label: def.label,
        from, to: item.zone, icon: "down",
        text: `placed the ${def.label} on ${zoneById(item.zone).label}`,
      });
      pushLog(w, "ok", `transition → ${def.label}: ${zoneById(from).short} → ${zoneById(item.zone).short}`);
    }

    if (item.kind === "state") {
      st.state = item.state;
      st.stateSince = w.t;
      st.lastSeen = w.t;
      w.metrics.transitions++;
      pushEvent(w, {
        t: w.t, kind: "state", entityId: def.id, label: def.label,
        to: item.state, icon: "bolt",
        text: `the ${def.label} is now ${item.state}`,
      });
      pushLog(w, "info", `state → ${def.label}: "${item.state}" @ ${fmtTs(w.t)}`);
    }
  }

  /* entity motion: held items ride the hand; others ease to their slot */
  for (const id of w.order) {
    const st = w.entities[id];
    const def = entityDef(id);
    if (st.held && w.handWin && w.handWin.carry === id) {
      const k = Math.min(1, Math.max(0, (w.loopT - (w.handWin.start + 0.35)) / Math.max(0.01, (w.handWin.end - 0.35) - (w.handWin.start + 0.35))));
      const e = k * k * (3 - 2 * k);
      st.roomX = w.handWin.fromX + (w.handWin.toX - w.handWin.fromX) * e;
    } else if (!st.held) {
      const slot = def.slots[st.zone] ?? st.roomX;
      st.roomX += (slot - st.roomX) * Math.min(1, dt * 4);
    }
    if (st.firstSeen !== null && w.t - (st.lastSeen ?? 0) > 2.5 && Math.abs(st.roomX - w.camX) < 240) {
      st.lastSeen = w.t; // in view, quietly keep fresh
    }
  }

  /* metrics */
  const fpsTarget = 24;
  w.metrics.fps = fpsTarget + Math.sin(w.t * 1.7) * 1.4 + Math.random() * 0.8;
  w.metrics.frames += dt * fpsTarget * (0.92 + Math.random() * 0.16);

  /* ready once memory feels populated */
  if (
    w.mode === "processing" &&
    Object.values(w.entities).filter((e) => e.firstSeen !== null).length >= 6 &&
    w.t > 9
  ) {
    w.mode = "ready";
    pushLog(w, "ok", "memory warm — you can ask me things now");
  }
}

/* ---------- verification queue ops ---------- */
export function resolveVerification(w: World, vid: string, ok: boolean) {
  const item = w.verifications.find((v) => v.id === vid);
  if (!item || item.status !== "pending") return null;
  item.status = ok ? "confirmed" : "rejected";
  const def = entityDef(item.entityId);
  if (ok) {
    def.conf = 0.88;
    const st = w.entities[item.entityId];
    st.conf = 0.88;
    pushLog(w, "ok", `human confirmed "${def.label}" — memory updated`);
  } else {
    pushLog(w, "warn", `human rejected "${def.label}" — kept as unverified`);
  }
  return item;
}

export function bootWorld(w: World) {
  if (w.unglugged) return false;
  w.mode = "booting";
  w.t = 0; w.loopT = 0; w.loop = 0;
  pushLog(w, "info", "chronicle vision booting — loading weights, opening eyes");
  return true;
}

export function beginFeed(w: World) {
  w.mode = "processing";
  pushLog(w, "ok", "feed live — watching your morning unfold");
}
