/* Chronicle renderer — draws the simulated head-cam feed onto a canvas.
   Reads the mutable World directly every frame. */

import { World, entityDef, ZONES, fmtT } from "./world";

export interface RenderOpts {
  dpr: number;
}

const W = 960;
const H = 600;

function sx(w: World, roomX: number): number {
  return (roomX - w.camX) * 1.18 + W / 2;
}

function depthScale(roomX: number): number {
  if (roomX > 560) return 1.14; // table area (closer)
  if (roomX > 420 && roomX < 560) return 0.82; // shelf (far)
  return 1.0;
}

/* ---------- background ---------- */
function drawRoom(ctx: CanvasRenderingContext2D, w: World) {
  // wall
  ctx.fillStyle = "#e7d7b8";
  ctx.fillRect(0, 0, W, H);

  // wall parallax offset (slower than objects)
  const wallShift = (w.camX - 500) * 0.35;

  // window
  const wx = 560 - wallShift;
  const wy = 70;
  const ww = 210, wh = 170;
  ctx.fillStyle = "#c9b58f";
  ctx.fillRect(wx - 10, wy - 10, ww + 20, wh + 20);
  // sky
  const sky = ctx.createLinearGradient(0, wy, 0, wy + wh);
  sky.addColorStop(0, "#a8d8e8");
  sky.addColorStop(1, "#e6f2d9");
  ctx.fillStyle = sky;
  ctx.fillRect(wx, wy, ww, wh);
  // sun
  ctx.fillStyle = "#ffd34d";
  ctx.beginPath();
  ctx.arc(wx + ww * 0.72, wy + wh * 0.3, 22, 0, Math.PI * 2);
  ctx.fill();
  // clouds
  ctx.fillStyle = "rgba(255,255,255,0.85)";
  for (const [cx, cy, r] of [[wx + 50, wy + 44, 16], [wx + 70, wy + 50, 20], [wx + 128, wy + 110, 14], [wx + 148, wy + 116, 17]]) {
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill();
  }
  // window cross
  ctx.strokeStyle = "#8a744c";
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(wx + ww / 2, wy); ctx.lineTo(wx + ww / 2, wy + wh);
  ctx.moveTo(wx, wy + wh / 2); ctx.lineTo(wx + ww, wy + wh / 2);
  ctx.stroke();

  // door (far right)
  const dx = 1085 - wallShift;
  ctx.fillStyle = "#b98a54";
  ctx.fillRect(dx, H - 330, 120, 330);
  ctx.strokeStyle = "#8a6238";
  ctx.lineWidth = 5;
  ctx.strokeRect(dx + 3, H - 327, 114, 324);
  ctx.fillStyle = "#6b4d2c";
  ctx.beginPath();
  ctx.arc(dx + 100, H - 175, 7, 0, Math.PI * 2);
  ctx.fill();

  // shelf
  const shx = 470 - wallShift * 0.75;
  ctx.fillStyle = "#a97b46";
  ctx.fillRect(shx - 95, 250, 190, 14);
  ctx.fillStyle = "#8a6238";
  ctx.fillRect(shx - 88, 264, 8, 26);
  ctx.fillRect(shx + 80, 264, 8, 26);

  // counter (left)
  const cx0 = 40 - wallShift * 0.9;
  ctx.fillStyle = "#d9c49a";
  ctx.fillRect(cx0, 330, 420, H - 330);
  // cabinet lines
  ctx.strokeStyle = "#b89f70";
  ctx.lineWidth = 4;
  for (const gx of [110, 210, 310]) {
    ctx.beginPath();
    ctx.moveTo(cx0 + gx - 20, 340);
    ctx.lineTo(cx0 + gx - 20, H - 10);
    ctx.stroke();
  }
  // counter top
  ctx.fillStyle = "#f0e6cf";
  ctx.fillRect(cx0 - 14, 312, 448, 26);
  ctx.strokeStyle = "#8a744c";
  ctx.lineWidth = 4;
  ctx.strokeRect(cx0 - 14, 312, 448, 26);
  // sink
  const skx = cx0 + 250;
  ctx.fillStyle = "#b9c4c6";
  ctx.fillRect(skx, 316, 120, 18);
  ctx.fillStyle = "#9aa8ab";
  ctx.fillRect(skx + 14, 300, 92, 18);
  // faucet
  ctx.strokeStyle = "#7c8a8d";
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.moveTo(skx + 100, 316);
  ctx.lineTo(skx + 100, 270);
  ctx.quadraticCurveTo(skx + 100, 250, skx + 78, 250);
  ctx.lineTo(skx + 66, 250);
  ctx.stroke();

  // table (right, foreground)
  const tx = 585 - wallShift * 1.05;
  ctx.fillStyle = "#c98a4b";
  ctx.fillRect(tx, 420, 470, 26);
  ctx.strokeStyle = "#96652f";
  ctx.lineWidth = 5;
  ctx.strokeRect(tx + 2, 422, 466, 22);
  // legs
  ctx.fillStyle = "#a9713a";
  ctx.fillRect(tx + 30, 446, 22, H - 446);
  ctx.fillRect(tx + 410, 446, 22, H - 446);

  // floor
  ctx.fillStyle = "#cbb891";
  ctx.fillRect(0, H - 62, W, 62);
  ctx.strokeStyle = "rgba(138,116,76,0.4)";
  ctx.lineWidth = 2;
  for (let i = 0; i < 10; i++) {
    const fx = ((i * 140 - wallShift) % (W + 140)) - 70;
    ctx.beginPath();
    ctx.moveTo(fx, H - 62);
    ctx.lineTo(fx - 30, H);
    ctx.stroke();
  }
}

/* ---------- little entity sprites ---------- */
function outline(ctx: CanvasRenderingContext2D) {
  ctx.strokeStyle = "#26221a";
  ctx.lineWidth = 2.5;
  ctx.stroke();
}

function drawEntity(ctx: CanvasRenderingContext2D, w: World, id: string, x: number, baseY: number, s: number, t: number) {
  const def = entityDef(id);
  ctx.save();
  ctx.translate(x, baseY);
  ctx.scale(s, s);
  ctx.fillStyle = def.colorHex;

  switch (def.kind) {
    case "mug": {
      ctx.fillRect(-16, -34, 32, 34);
      outline(ctx);
      // handle
      ctx.beginPath();
      ctx.arc(20, -18, 9, -Math.PI / 2, Math.PI / 2);
      outline(ctx);
      // coffee surface
      ctx.fillStyle = "#5a3d28";
      ctx.fillRect(-12, -32, 24, 5);
      break;
    }
    case "cup": {
      ctx.beginPath();
      ctx.moveTo(-13, -30);
      ctx.lineTo(-9, 0);
      ctx.lineTo(9, 0);
      ctx.lineTo(13, -30);
      ctx.closePath();
      ctx.fill();
      outline(ctx);
      ctx.beginPath();
      ctx.arc(16, -16, 7, -Math.PI / 2, Math.PI / 2);
      outline(ctx);
      break;
    }
    case "bowl": {
      ctx.beginPath();
      ctx.arc(0, -4, 22, 0, Math.PI);
      ctx.closePath();
      ctx.fill();
      outline(ctx);
      ctx.fillStyle = "#f6f1e2";
      ctx.beginPath();
      ctx.ellipse(0, -6, 22, 6, 0, 0, Math.PI * 2);
      ctx.fill();
      outline(ctx);
      break;
    }
    case "apple": {
      ctx.beginPath();
      ctx.arc(0, -12, 13, 0, Math.PI * 2);
      ctx.fill();
      outline(ctx);
      ctx.strokeStyle = "#5a3d28";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(0, -24);
      ctx.quadraticCurveTo(2, -32, 6, -34);
      ctx.stroke();
      ctx.fillStyle = "#4e9b5e";
      ctx.beginPath();
      ctx.ellipse(9, -33, 6, 3, 0.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.beginPath();
      ctx.arc(-4, -17, 3.5, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "banana": {
      ctx.strokeStyle = def.colorHex;
      ctx.lineWidth = 10;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.arc(0, -4, 18, Math.PI * 0.15, Math.PI * 0.85);
      ctx.stroke();
      ctx.strokeStyle = "#26221a";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(0, -4, 18, Math.PI * 0.15, Math.PI * 0.85);
      ctx.stroke();
      ctx.lineCap = "butt";
      break;
    }
    case "book": {
      ctx.fillRect(-22, -12, 44, 12);
      outline(ctx);
      ctx.fillStyle = "#fffdf4";
      ctx.fillRect(-22, -12, 6, 12);
      outline(ctx);
      break;
    }
    case "laptop": {
      const open = w.entities.laptop.state.includes("open");
      ctx.fillRect(-34, -8, 68, 8); // base
      outline(ctx);
      if (open) {
        ctx.save();
        ctx.translate(-34, -8);
        ctx.transform(1, -0.12, 0, 1, 0, 0);
        ctx.fillStyle = "#3a3a38";
        ctx.fillRect(0, -58, 68, 58);
        outline(ctx);
        // screen glow
        ctx.fillStyle = w.entities.laptop.state.includes("on") ? "#cde8c2" : "#4a4a48";
        ctx.fillRect(5, -52, 58, 46);
        if (w.entities.laptop.state.includes("on")) {
          ctx.fillStyle = "#37c585";
          for (let i = 0; i < 3; i++) {
            const gy = -46 + i * 14 + Math.sin(t * 2 + i) * 1.5;
            ctx.fillRect(10, gy, 30 + Math.sin(t * 3 + i * 2) * 12, 4);
          }
        }
        ctx.restore();
      } else {
        ctx.fillStyle = "#3a3a38";
        ctx.fillRect(-34, -12, 68, 6);
        outline(ctx);
      }
      break;
    }
    case "phone": {
      ctx.fillRect(-9, -18, 18, 18);
      outline(ctx);
      ctx.fillStyle = "rgba(255,255,255,0.25)";
      ctx.fillRect(-6, -15, 12, 5);
      break;
    }
    case "plant": {
      // pot
      ctx.fillStyle = "#c6553b";
      ctx.beginPath();
      ctx.moveTo(-16, -22);
      ctx.lineTo(16, -22);
      ctx.lineTo(11, 0);
      ctx.lineTo(-11, 0);
      ctx.closePath();
      ctx.fill();
      outline(ctx);
      // leaves
      ctx.fillStyle = def.colorHex;
      for (const [a, len] of [[-1.9, 34], [-1.35, 42], [-0.6, 44], [0.1, 40], [0.8, 36], [1.6, 30]]) {
        ctx.save();
        ctx.translate(0, -22);
        ctx.rotate(a + Math.sin(t * 1.4 + len) * 0.05);
        ctx.beginPath();
        ctx.ellipse(0, -len / 2, 7, len / 2, 0, 0, Math.PI * 2);
        ctx.fill();
        outline(ctx);
        ctx.restore();
      }
      break;
    }
    case "backpack": {
      ctx.beginPath();
      ctx.roundRect(-26, -52, 52, 52, 12);
      ctx.fill();
      outline(ctx);
      ctx.fillStyle = "rgba(38,34,26,0.25)";
      ctx.fillRect(-26, -30, 52, 7);
      const open = w.entities.backpack.state.includes("open");
      if (open) {
        ctx.fillStyle = "#3d3d22";
        ctx.fillRect(-14, -50, 28, 16);
      } else {
        ctx.strokeStyle = "#3d3d22";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(-8, -52);
        ctx.lineTo(-8, -34);
        ctx.moveTo(8, -52);
        ctx.lineTo(8, -34);
        ctx.stroke();
      }
      // straps
      ctx.strokeStyle = "#26221a";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(0, -48, 14, Math.PI * 1.15, Math.PI * 1.85);
      ctx.stroke();
      break;
    }
  }
  ctx.restore();
}

function surfaceYFor(w: World, id: string): number {
  const def = entityDef(id);
  const st = w.entities[id];
  if (st.held) return H - 118;
  switch (st.zone) {
    case "counter": return 312;
    case "table": return 420;
    case "shelf": return 250;
    case "floor": return H - 58;
    default: return 312;
  }
}

/* ---------- hand ---------- */
function drawHand(ctx: CanvasRenderingContext2D, w: World) {
  if (!w.handWin) return;
  const k = Math.min(1, Math.max(0, (w.loopT - w.handWin.start) / Math.max(0.01, w.handWin.end - w.handWin.start)));
  const x = w.handWin.fromX + (w.handWin.toX - w.handWin.fromX) * k;
  const gx = sx(w, x);
  const reach = Math.sin(Math.min(1, k * 3.2) * Math.PI) * 26;
  const hy = H - 30 + reach;

  ctx.save();
  // forearm/sleeve
  ctx.fillStyle = "#e8b26b";
  ctx.beginPath();
  ctx.roundRect(gx - 24, hy + 26, 48, H - hy, 14);
  ctx.fill();
  ctx.strokeStyle = "#26221a";
  ctx.lineWidth = 2.5;
  ctx.stroke();
  // sleeve cuff
  ctx.fillStyle = "#37c585";
  ctx.beginPath();
  ctx.roundRect(gx - 26, hy + 12, 52, 22, 10);
  ctx.fill();
  ctx.stroke();
  // palm
  ctx.fillStyle = "#f2c396";
  ctx.beginPath();
  ctx.roundRect(gx - 22, hy - 26, 44, 46, 16);
  ctx.fill();
  ctx.stroke();
  // thumb
  ctx.fillStyle = "#f2c396";
  ctx.beginPath();
  ctx.roundRect(gx - 30, hy - 20, 14, 26, 7);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

/* ---------- detection HUD ---------- */
function drawDetections(ctx: CanvasRenderingContext2D, w: World, t: number) {
  // collect visible entities first, then de-crowd their label pills
  type Det = { id: string; px: number; by: number; bh: number; s: number; pinged: boolean };
  const dets: Det[] = [];
  for (const id of w.order) {
    const st = w.entities[id];
    if (st.firstSeen === null) continue;
    const px = sx(w, st.roomX);
    if (px < -80 || px > W + 80) continue;
    const s = depthScale(st.roomX);
    const py = surfaceYFor(w, id);
    const bw = 66 * s, bh = 64 * s;
    dets.push({ id, px, by: py - bh, bh, s, pinged: w.pings.some((p) => p.entityId === id && p.ttl > 0) });
  }
  dets.sort((a, b) => a.px - b.px);

  // label row assignment: push later labels down when they'd collide
  const rows: Array<{ x: number; row: number }> = [];
  for (const d of dets) {
    let row = 0;
    while (rows.some((r) => r.row === row && Math.abs(r.x - d.px) < 92)) row++;
    rows.push({ x: d.px, row });
  }

  dets.forEach((d, i) => {
    const st = w.entities[d.id];
    const def = entityDef(d.id);
    const col = d.pinged ? "#ffd34d" : "#f6efdd";
    const bw = 66 * d.s;
    const bx = d.px - bw / 2;
    const by = d.by;

    // corner brackets
    ctx.strokeStyle = col;
    ctx.lineWidth = 2.5;
    const cl = 10;
    const corners: Array<[number, number, number, number]> = [
      [bx, by, 1, 1], [bx + bw, by, -1, 1], [bx, by + d.bh, 1, -1], [bx + bw, by + d.bh, -1, -1],
    ];
    for (const [cx, cy, dxs, dys] of corners) {
      ctx.beginPath();
      ctx.moveTo(cx + dxs * cl, cy);
      ctx.lineTo(cx, cy);
      ctx.lineTo(cx, cy + dys * cl);
      ctx.stroke();
    }

    // label pill (row-shifted to avoid stacking)
    const text = `${def.label} ${Math.round(st.conf * 100)}%`;
    ctx.font = "600 11px 'IBM Plex Mono', monospace";
    const tw = ctx.measureText(text).width + 22;
    const ly = by - 20 - rows[i].row * 20;
    const lx = Math.min(W - tw / 2 - 8, Math.max(tw / 2 + 8, d.px));
    ctx.fillStyle = d.pinged ? "#ffd34d" : "#26221a";
    ctx.beginPath();
    ctx.roundRect(lx - tw / 2, ly, tw, 17, 4);
    ctx.fill();
    ctx.fillStyle = def.colorHex;
    ctx.beginPath();
    ctx.arc(lx - tw / 2 + 9, ly + 8.5, 3.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = d.pinged ? "#26221a" : "#faf3e3";
    ctx.fillText(text, lx - tw / 2 + 16, ly + 12);

    if (d.pinged) {
      const k = (t * 2) % 1;
      ctx.strokeStyle = "#ffd34d";
      ctx.lineWidth = 3;
      ctx.globalAlpha = 1 - k;
      ctx.beginPath();
      ctx.arc(d.px, by + d.bh / 2, 24 + k * 34, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
  });
}

/* ---------- static / glitch ---------- */
function drawStatic(ctx: CanvasRenderingContext2D, label: string) {
  ctx.fillStyle = "#171410";
  ctx.fillRect(0, 0, W, H);
  for (let i = 0; i < 340; i++) {
    const g = 20 + Math.random() * 70;
    ctx.fillStyle = `rgb(${g},${g},${g - 8})`;
    ctx.fillRect(Math.random() * W, Math.random() * H, 3 + Math.random() * 10, 2 + Math.random() * 4);
  }
  ctx.fillStyle = "rgba(38,34,26,0.5)";
  ctx.fillRect(0, H / 2 - 34, W, 68);
  ctx.fillStyle = "#faf3e3";
  ctx.font = "800 30px 'Bricolage Grotesque', sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(label, W / 2, H / 2 + 10);
  ctx.font = "500 13px 'IBM Plex Mono', monospace";
  ctx.fillStyle = "#b9ad93";
  ctx.fillText("ch-00 · no feed detected", W / 2, H / 2 + 38);
  ctx.textAlign = "left";
}

function drawBoot(ctx: CanvasRenderingContext2D, t: number) {
  ctx.fillStyle = "#171410";
  ctx.fillRect(0, 0, W, H);
  // glitch bars
  for (let i = 0; i < 14; i++) {
    const y = Math.random() * H;
    const h = 2 + Math.random() * 16;
    ctx.fillStyle = ["#37c585", "#ffd34d", "#ff6b4a", "#f6efdd"][i % 4];
    ctx.globalAlpha = 0.12 + Math.random() * 0.2;
    ctx.fillRect(0, y, W, h);
  }
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#faf3e3";
  ctx.font = "800 26px 'Bricolage Grotesque', sans-serif";
  ctx.textAlign = "center";
  const dots = ".".repeat(1 + Math.floor(t * 3) % 3);
  ctx.fillText(`CHRONICLE VISION BOOTING${dots}`, W / 2, H / 2 - 6);
  ctx.font = "500 13px 'IBM Plex Mono', monospace";
  ctx.fillStyle = "#37c585";
  ctx.fillText("loading weights · opening eyes · warming memory", W / 2, H / 2 + 24);
  ctx.textAlign = "left";
}

function drawRewind(ctx: CanvasRenderingContext2D) {
  for (let i = 0; i < 10; i++) {
    const y = Math.random() * H;
    const h = 6 + Math.random() * 30;
    ctx.fillStyle = "rgba(255,211,77,0.18)";
    ctx.fillRect(0, y, W, h);
  }
  ctx.fillStyle = "#faf3e3";
  ctx.font = "800 20px 'Bricolage Grotesque', sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("↺  re-walking the scene", W / 2, 60);
  ctx.textAlign = "left";
}

/* ---------- main frame ---------- */
export function drawFrame(
  ctx: CanvasRenderingContext2D,
  w: World,
  opts: RenderOpts
) {
  const t = w.t;
  ctx.save();
  ctx.scale(opts.dpr, opts.dpr);

  if (w.mode === "idle") {
    drawStatic(ctx, "NO SIGNAL");
    ctx.restore();
    return;
  }
  if (w.mode === "error") {
    drawStatic(ctx, "SIGNAL LOST");
    ctx.restore();
    return;
  }
  if (w.mode === "booting") {
    drawBoot(ctx, t);
    ctx.restore();
    return;
  }

  const paused = w.mode === "paused";

  // camera bob (subtle, walking feel)
  const moving = !paused && Math.abs(camDelta(w)) > 0.8;
  const bobY = moving ? Math.sin(t * 7) * 3.2 : Math.sin(t * 1.8) * 1.1;

  ctx.save();
  ctx.translate(0, bobY);

  drawRoom(ctx, w);

  // entities back-to-front by depth
  const drawOrder = [...w.order].sort((a, b) => depthScale(w.entities[a].roomX) - depthScale(w.entities[b].roomX));
  const held = w.order.find((id) => w.entities[id].held);

  for (const id of drawOrder) {
    const st = w.entities[id];
    if (st.firstSeen === null || st.held) continue;
    const px = sx(w, st.roomX);
    if (px < -120 || px > W + 120) continue;
    const s = depthScale(st.roomX);
    // soft shadow
    ctx.fillStyle = "rgba(38,34,26,0.18)";
    ctx.beginPath();
    ctx.ellipse(px, surfaceYFor(w, id) + 2, 24 * s, 5 * s, 0, 0, Math.PI * 2);
    ctx.fill();
    drawEntity(ctx, w, id, px, surfaceYFor(w, id), s * 1.35, t);
  }

  drawHand(ctx, w);
  if (held) {
    const st = w.entities[held];
    const px = sx(w, st.roomX);
    drawEntity(ctx, w, held, px, H - 116, 1.25, t);
  }

  ctx.restore(); // bob

  // vignette
  const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.45, W / 2, H / 2, H * 0.95);
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(10,8,5,0.42)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);

  // detections + HUD
  if (!paused) drawDetections(ctx, w, t);

  // scanline
  const scanY = ((t * 0.24) % 1) * (H + 60) - 30;
  const sg = ctx.createLinearGradient(0, scanY - 30, 0, scanY + 30);
  sg.addColorStop(0, "rgba(255,211,77,0)");
  sg.addColorStop(0.5, "rgba(255,211,77,0.16)");
  sg.addColorStop(1, "rgba(255,211,77,0)");
  ctx.fillStyle = sg;
  ctx.fillRect(0, scanY - 30, W, 60);
  ctx.fillStyle = "rgba(255,211,77,0.5)";
  ctx.fillRect(0, scanY, W, 1.5);

  // zone tag (what region the head-cam is looking at)
  let near = ZONES[0];
  for (const z of ZONES) if (Math.abs(z.roomX - w.camX) < Math.abs(near.roomX - w.camX)) near = z;
  ctx.font = "600 12px 'IBM Plex Mono', monospace";
  const zt = `◉ ${near.short}`;
  const ztw = ctx.measureText(zt).width + 18;
  ctx.fillStyle = "rgba(23,20,16,0.72)";
  ctx.beginPath();
  ctx.roundRect(16, H - 40, ztw, 24, 6);
  ctx.fill();
  ctx.strokeStyle = "rgba(250,243,227,0.35)";
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.fillStyle = "#faf3e3";
  ctx.fillText(zt, 25, H - 23);

  // REC + LIVE
  ctx.fillStyle = "rgba(23,20,16,0.72)";
  ctx.beginPath();
  ctx.roundRect(16, 16, 118, 26, 6);
  ctx.fill();
  ctx.fillStyle = "#ff6b4a";
  ctx.beginPath();
  ctx.arc(32, 29, 5.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#faf3e3";
  ctx.font = "700 12px 'IBM Plex Mono', monospace";
  ctx.fillText(paused ? "PAUSED" : "LIVE · REC", 44, 33);

  // timestamp
  const ts = fmtT(w.t);
  ctx.font = "600 13px 'IBM Plex Mono', monospace";
  const tsw = ctx.measureText(ts).width + 20;
  ctx.fillStyle = "rgba(23,20,16,0.72)";
  ctx.beginPath();
  ctx.roundRect(W - tsw - 16, 16, tsw, 26, 6);
  ctx.fill();
  ctx.fillStyle = "#ffd34d";
  ctx.fillText(ts, W - tsw - 6, 33);

  // watermark
  ctx.font = "500 10px 'IBM Plex Mono', monospace";
  ctx.fillStyle = "rgba(250,243,227,0.4)";
  ctx.fillText("chronicle · sim rig A", W - 140, H - 22);

  if (w.rewinding > 0) drawRewind(ctx);

  ctx.restore();
}

function camDelta(w: World): number {
  // rough estimate of camera motion for bob — not critical
  return (w.camOverride ? w.camOverride.targetX - w.camX : 0) || Math.sin(w.loopT * 0.7) * 30;
}
