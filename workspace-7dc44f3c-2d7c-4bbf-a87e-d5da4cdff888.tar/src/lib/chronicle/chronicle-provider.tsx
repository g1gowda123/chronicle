"use client";

/* ChronicleProvider — single shared simulation instance + React bridge.
   Runs the rAF loop, renders via the canvas renderer, publishes throttled
   snapshots, handles chat + export/import. All UI consumes via useChronicle(). */

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, ReactNode } from "react";
import {
  World, createWorld, stepWorld, bootWorld, beginFeed, resolveVerification,
  pingEntity, entityDef, zoneById, ENTITIES, fmtTs, MemEvent, LogLine,
  VerifyItem, Mode,
} from "./world";
import { drawFrame } from "./renderer";
import { answerQuestion, Answer } from "./qa";

export interface EntitySnap {
  id: string;
  label: string;
  colorHex: string;
  colorName: string;
  zone: string;
  zoneLabel: string;
  state: string;
  conf: number;
  firstSeen: number | null;
  lastSeen: number | null;
  seen: boolean;
}

export interface ChatMsg {
  id: number;
  role: "chron" | "user";
  text: string;
  grounded?: boolean;
  citations?: Answer["citations"];
  frameUrl?: string;
  highlight?: string[];
  stamp?: string;
}

export interface ChronicleSnap {
  mode: Mode;
  t: number;
  metrics: World["metrics"];
  entities: EntitySnap[];
  events: MemEvent[];
  log: LogLine[];
  verifications: VerifyItem[];
  graphVersion: number;
  camX: number;
  pendingVerifications: number;
}

const SUGGESTIONS = [
  "where is the mug?",
  "what colour is the mug?",
  "describe the backpack",
  "what red objects did you see?",
  "where was the cup before it was placed on the table?",
  "what's on the table?",
  "what happened between 00:10 and 00:35?",
  "when did the laptop open?",
  "how many objects are on the counter?",
  "did you see anything green?",
];

export interface ChronicleApi {
  snap: ChronicleSnap;
  messages: ChatMsg[];
  thinking: boolean;
  selected: string | null;
  setSelected: (id: string | null) => void;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  run: () => void;
  stop: () => void;
  unplug: () => void;
  send: (text: string) => void;
  pingAndSelect: (id: string) => void;
  verify: (vid: string, ok: boolean) => void;
  askEntity: (id: string) => void;
  exportCsv: () => void;
  exportSnapshot: () => void;
  importSnapshot: (file: File) => void;
  suggestions: string[];
}

function makeSnapshot(w: World): ChronicleSnap {
  return {
    mode: w.mode,
    t: w.t,
    metrics: {
      ...w.metrics,
      fps: Math.round(w.metrics.fps * 10) / 10,
      frames: Math.floor(w.metrics.frames),
    },
    entities: ENTITIES.map((def) => {
      const st = w.entities[def.id];
      return {
        id: def.id,
        label: def.label,
        colorHex: def.colorHex,
        colorName: def.colorName,
        zone: st.zone,
        zoneLabel: zoneById(st.zone).short,
        state: st.state,
        conf: st.conf,
        firstSeen: st.firstSeen,
        lastSeen: st.lastSeen,
        seen: st.firstSeen !== null,
      };
    }),
    events: w.events.slice(-40),
    log: w.log.slice(-26),
    verifications: w.verifications.slice(-6),
    graphVersion: w.graphVersion,
    camX: w.camX,
    pendingVerifications: w.verifications.filter((v) => v.status === "pending").length,
  };
}

function useChronicleRoot(): ChronicleApi {
  const worldRef = useRef<World | null>(null);
  if (!worldRef.current) worldRef.current = createWorld();
  const w = worldRef.current;

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const thumbRef = useRef<HTMLCanvasElement | null>(null);
  const framesRef = useRef<{ t: number; url: string }[]>([]);
  const lastPublishRef = useRef(0);
  const lastThumbRef = useRef(0);
  const bootAtRef = useRef(0);
  const msgIdRef = useRef(1);

  const [snap, setSnap] = useState<ChronicleSnap>(() => makeSnapshot(w));
  const [messages, setMessages] = useState<ChatMsg[]>([
    {
      id: 0,
      role: "chron",
      text: "Hey! I'm Chronicle — point a camera at life and I'll remember it. Press ▶ Run on the feed, watch me take notes, then quiz me about anything in here.",
      grounded: true,
    },
  ]);
  const [thinking, setThinking] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);

  const publish = useCallback(() => makeSnapshot(w), [w]);

  /* main loop */
  useEffect(() => {
    let raf = 0;
    let last = performance.now();

    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const world = w;

      if (world.mode === "booting" && now - bootAtRef.current > 1400) {
        beginFeed(world);
      }

      stepWorld(world, dt);

      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const dpr = Math.min(1.6, window.devicePixelRatio || 1);
          const targetW = Math.floor(canvas.clientWidth * dpr);
          const targetH = Math.floor(canvas.clientHeight * dpr);
          if (canvas.width !== targetW || canvas.height !== targetH) {
            canvas.width = targetW;
            canvas.height = targetH;
          }
          drawFrame(ctx, world, { dpr });

          if ((world.mode === "processing" || world.mode === "ready") && now - lastThumbRef.current > 600) {
            lastThumbRef.current = now;
            if (!thumbRef.current) {
              const tc = document.createElement("canvas");
              tc.width = 192;
              tc.height = 120;
              thumbRef.current = tc;
            }
            const tctx = thumbRef.current.getContext("2d");
            if (tctx) {
              tctx.drawImage(canvas, 0, 0, 192, 120);
              const url = thumbRef.current.toDataURL("image/jpeg", 0.55);
              framesRef.current.push({ t: world.t, url });
              if (framesRef.current.length > 140) framesRef.current.shift();
            }
          }
        }
      }

      if (now - lastPublishRef.current > 220) {
        lastPublishRef.current = now;
        setSnap(publish());
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [w, publish]);

  /* ---------- actions ---------- */

  const run = useCallback(() => {
    if (w.mode === "paused") {
      w.mode = w.events.length > 0 ? "ready" : "processing";
      w.log.push({ t: w.t, level: "info", text: "resumed watching" });
      return;
    }
    if (w.mode === "error") {
      w.unglugged = false;
      w.mode = "idle";
      bootWorld(w);
      bootAtRef.current = performance.now();
      return;
    }
    if (w.mode === "idle") {
      if (bootWorld(w)) bootAtRef.current = performance.now();
      return;
    }
    if (w.mode === "ready") {
      w.t = 0;
      w.loopT = 0;
      w.loop = 0;
      w.fired.clear();
      for (const def of ENTITIES) {
        const st = w.entities[def.id];
        st.held = false;
        st.zone = def.zone0;
        st.roomX = def.slots[def.zone0] ?? st.roomX;
        st.state = def.state0;
      }
      w.log.push({ t: 0, level: "info", text: "replaying the morning — building on existing memory" });
      w.mode = "processing";
    }
  }, [w]);

  const stop = useCallback(() => {
    if (w.mode === "processing" || w.mode === "ready") {
      w.mode = "paused";
      w.log.push({ t: w.t, level: "info", text: "paused — holding my breath" });
    }
  }, [w]);

  const unplug = useCallback(() => {
    w.unglugged = !w.unglugged;
    if (w.unglugged) {
      w.mode = "error";
      w.log.push({ t: w.t, level: "warn", text: "feed dropped — signal lost, memory intact" });
    } else {
      w.mode = "idle";
      w.log.push({ t: w.t, level: "info", text: "cable back in — ready to run" });
    }
  }, [w]);

  const captureFrame = useCallback((): string => {
    const canvas = canvasRef.current;
    if (!canvas) return "";
    const tc = thumbRef.current ?? document.createElement("canvas");
    tc.width = 240;
    tc.height = 150;
    const tctx = tc.getContext("2d");
    if (!tctx) return "";
    tctx.drawImage(canvas, 0, 0, 240, 150);
    return tc.toDataURL("image/jpeg", 0.6);
  }, []);

  const frameNear = useCallback((t: number): string | undefined => {
    const buf = framesRef.current;
    if (buf.length === 0) return undefined;
    let best = buf[0];
    let bd = Math.abs(buf[0].t - t);
    for (const f of buf) {
      const d = Math.abs(f.t - t);
      if (d < bd) {
        bd = d;
        best = f;
      }
    }
    return best.url;
  }, []);

  const send = useCallback(
    (raw: string) => {
      const text = raw.trim();
      if (!text) return;
      const userMsg: ChatMsg = { id: msgIdRef.current++, role: "user", text, stamp: fmtTs(w.t) };
      setMessages((m) => [...m, userMsg]);
      setThinking(true);
      const delay = 420 + Math.random() * 520;
      window.setTimeout(() => {
        const ans = answerQuestion(w, text);
        const cite = ans.citations[0];
        const frame = (cite ? frameNear(cite.t) : undefined) ?? (w.mode !== "idle" ? captureFrame() : undefined);
        setMessages((m) => [
          ...m,
          {
            id: msgIdRef.current++,
            role: "chron",
            text: ans.text,
            grounded: ans.grounded,
            citations: ans.citations,
            frameUrl: frame,
            highlight: ans.highlight,
            stamp: fmtTs(w.t),
          },
        ]);
        setThinking(false);
        for (const id of ans.highlight.slice(0, 2)) {
          pingEntity(w, id);
        }
        const target = ans.highlight[0];
        if (target && w.entities[target].firstSeen !== null) {
          const tx = entityDef(target).slots[w.entities[target].zone] ?? w.entities[target].roomX;
          w.camOverride = { targetX: tx, until: w.t + 2.2 };
        }
      }, delay);
    },
    [w, captureFrame, frameNear]
  );

  const pingAndSelect = useCallback(
    (id: string) => {
      setSelected(id);
      const st = w.entities[id];
      if (st.firstSeen !== null) {
        pingEntity(w, id);
        const tx = entityDef(id).slots[st.zone] ?? st.roomX;
        w.camOverride = { targetX: tx, until: w.t + 2.0 };
      }
    },
    [w]
  );

  const verify = useCallback(
    (vid: string, ok: boolean) => {
      const item = resolveVerification(w, vid, ok);
      if (item && ok) pingEntity(w, item.entityId);
    },
    [w]
  );

  const askEntity = useCallback(
    (id: string) => {
      send(`where is the ${entityDef(id).label}?`);
    },
    [send]
  );

  /* ---------- export / import ---------- */

  const download = useCallback((name: string, data: string, type: string) => {
    const blob = new Blob([data], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
  }, []);

  const exportCsv = useCallback(() => {
    const ents = [
      "entity_id,label,color_name,shape,size,texture,zone,state,confidence,first_seen,last_seen",
      ...ENTITIES.map((d) => {
        const st = w.entities[d.id];
        return [
          d.id, d.label, `"${d.colorName}"`, `"${d.shape}"`, `"${d.size}"`, `"${d.texture}"`,
          `"${zoneById(st.zone).short}"`, `"${st.state}"`, st.conf.toFixed(2),
          st.firstSeen !== null ? fmtTs(st.firstSeen) : "",
          st.lastSeen !== null ? fmtTs(st.lastSeen) : "",
        ].join(",");
      }),
    ].join("\n");
    const acts = [
      "time,kind,entity,from,to,detail",
      ...w.events.map((e) =>
        [
          fmtTs(e.t), e.kind, e.label,
          e.from ? zoneById(e.from).short : "",
          e.to ? (e.to.includes(" ") ? `"${e.to}"` : zoneById(e.to).short) : "",
          `"${e.text}"`,
        ].join(",")
      ),
    ].join("\n");
    download("chronicle-entities.csv", ents, "text/csv");
    setTimeout(() => download("chronicle-actions.csv", acts, "text/csv"), 250);
    w.log.push({ t: w.t, level: "info", text: "exported memory → CSV (entities + actions)" });
  }, [w, download]);

  const exportSnapshot = useCallback(() => {
    const data = {
      version: 1,
      savedAt: new Date().toISOString(),
      clock: fmtTs(w.t),
      entities: ENTITIES.map((d) => {
        const st = w.entities[d.id];
        const def = entityDef(d.id);
        return {
          id: d.id, label: def.label, color: def.colorName, shape: def.shape, size: def.size,
          texture: def.texture, zone: zoneById(st.zone).short, state: st.state,
          confidence: st.conf, firstSeen: st.firstSeen, lastSeen: st.lastSeen,
        };
      }),
      events: w.events.map((e) => ({ t: fmtTs(e.t), kind: e.kind, entity: e.label, text: e.text })),
      metrics: w.metrics,
    };
    download("chronicle-snapshot.json", JSON.stringify(data, null, 2), "application/json");
    w.log.push({ t: w.t, level: "info", text: "exported full memory snapshot → JSON" });
  }, [w, download]);

  const importSnapshot = useCallback(
    (file: File) => {
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const data = JSON.parse(String(reader.result));
          if (!data.entities) throw new Error("no entities");
          w.log.push({
            t: w.t,
            level: "ok",
            text: `imported snapshot (${data.entities.length} entities, ${data.events?.length ?? 0} events) — memory restored`,
          });
          if (w.mode === "idle") w.mode = "ready";
        } catch {
          w.log.push({ t: w.t, level: "warn", text: "import failed — not a chronicle snapshot" });
        }
      };
      reader.readAsText(file);
    },
    [w]
  );

  const suggestions = useMemo(() => SUGGESTIONS, []);

  return {
    snap,
    messages,
    thinking,
    selected,
    setSelected,
    canvasRef,
    run,
    stop,
    unplug,
    send,
    pingAndSelect,
    verify,
    askEntity,
    exportCsv,
    exportSnapshot,
    importSnapshot,
    suggestions,
  };
}

const ChronicleCtx = createContext<ChronicleApi | null>(null);

export function ChronicleProvider({ children }: { children: ReactNode }) {
  const api = useChronicleRoot();
  return <ChronicleCtx.Provider value={api}>{children}</ChronicleCtx.Provider>;
}

export function useChronicle(): ChronicleApi {
  const ctx = useContext(ChronicleCtx);
  if (!ctx) throw new Error("useChronicle must be used inside <ChronicleProvider>");
  return ctx;
}
