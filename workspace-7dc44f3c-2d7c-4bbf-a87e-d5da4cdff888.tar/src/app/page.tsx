"use client";

import { useRef } from "react";
import { ChronicleProvider, useChronicle } from "@/lib/chronicle/chronicle-provider";
import { VideoStage } from "@/components/chronicle/video-stage";
import { ChatPanel } from "@/components/chronicle/chat-panel";
import { MemoryGraph } from "@/components/chronicle/memory-graph";
import { EntityList, EntityInspector } from "@/components/chronicle/entities";
import { Timeline, ActionList, VerifyQueue, ModelStatus, Telemetry } from "@/components/chronicle/panels";
import { EyeLogo, MetricChip, StarDoodle, StatusPill } from "@/components/chronicle/bits";

export default function Home() {
  return (
    <ChronicleProvider>
      <ChronicleApp />
    </ChronicleProvider>
  );
}

function ChronicleApp() {
  const { snap, exportCsv, exportSnapshot, importSnapshot } = useChronicle();
  const importRef = useRef<HTMLInputElement>(null);

  return (
    <div className="min-h-screen flex flex-col">
      {/* ================= header ================= */}
      <header className="sticky top-0 z-40 border-b-2 border-ink bg-paper/95 backdrop-blur">
        <div className="max-w-[1400px] mx-auto px-4 py-2.5 flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2.5">
            <EyeLogo className="w-9 h-9 floaty" />
            <div className="leading-none">
              <h1 className="font-display font-extrabold text-xl tracking-tight">
                Chronicle<span className="text-coral">.</span>
              </h1>
              <p className="font-hand text-[15px] text-inksoft -mt-0.5">a head-cam that remembers</p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-1.5 ml-2">
            <MetricChip label="frames" value={snap.metrics.frames.toLocaleString()} />
            <MetricChip label="fps" value={snap.metrics.fps} />
            <MetricChip label="entities" value={snap.entities.filter((e) => e.seen).length} accent="text-coral" />
            <MetricChip label="actions" value={snap.metrics.actions} />
            <MetricChip label="transitions" value={snap.metrics.transitions} />
          </div>

          <div className="grow" />

          <StatusPill mode={snap.mode} />

          <div className="flex items-center gap-1.5">
            <button className="btnz" onClick={exportSnapshot} title="download full memory as JSON">
              <svg viewBox="0 0 16 16" className="w-3.5 h-3.5" fill="none" aria-hidden>
                <path d="M8 2 V10 M4.5 7 L8 10.5 L11.5 7 M3 13 H13" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              snapshot
            </button>
            <button className="btnz" onClick={exportCsv} title="download entities + actions as CSV">
              <svg viewBox="0 0 16 16" className="w-3.5 h-3.5" fill="none" aria-hidden>
                <rect x="2" y="2.5" width="12" height="11" rx="1.5" stroke="currentColor" strokeWidth="1.7" />
                <path d="M2 6 H14 M2 9.5 H14 M6 6 V13.5 M10 6 V13.5" stroke="currentColor" strokeWidth="1.4" />
              </svg>
              CSV
            </button>
            <button className="btnz" onClick={() => importRef.current?.click()} title="restore a snapshot">
              <svg viewBox="0 0 16 16" className="w-3.5 h-3.5" fill="none" aria-hidden>
                <path d="M8 10.5 V2.5 M4.5 6 L8 2.5 L11.5 6 M3 13 H13" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              import
            </button>
            <input
              ref={importRef}
              type="file"
              accept="application/json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) importSnapshot(f);
                e.target.value = "";
              }}
            />
          </div>
        </div>
      </header>

      {/* ================= main ================= */}
      <main className="max-w-[1400px] w-full mx-auto px-4 py-5 grow">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* -------- left: big video + chat right below -------- */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            <VideoStage />
            <ChatPanel />
          </div>

          {/* -------- right rail: graph, inspector, list -------- */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            <MemoryGraph />
            <EntityInspector />
            <EntityList />
          </div>
        </div>

        {/* -------- bottom strip -------- */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 mt-6">
          <div className="xl:col-span-2 flex flex-col gap-5">
            <Timeline />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <ActionList />
              <VerifyQueue />
            </div>
          </div>
          <div className="flex flex-col gap-5">
            <ModelStatus />
            <Telemetry />
          </div>
        </div>

        {/* marquee strip of fun */}
        <div className="zcard overflow-hidden mt-6 rot-l" aria-hidden>
          <div className="bg-mustard border-b-2 border-ink py-1.5 whitespace-nowrap font-display font-bold text-[13px]">
            <div style={{ animation: "marquee 26s linear infinite", width: "max-content" }}>
              {Array.from({ length: 2 }).map((_, i) => (
                <span key={i}>
                  {Array.from({ length: 4 }).map((_, j) => (
                    <span key={j} className="mx-6">
                      ✦ chronicle remembers objects ✦ colours ✦ places ✦ states ✦ actions ✦ ask it anything — grounded answers only ✦ no hallucinating, pinky promise ✦
                    </span>
                  ))}
                </span>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* ================= footer ================= */}
      <footer className="mt-auto border-t-2 border-ink bg-cardz">
        <div className="max-w-[1400px] mx-auto px-4 py-3 flex flex-wrap items-center gap-2 justify-between">
          <p className="font-hand text-lg text-inksoft">
            built with too much coffee · chronicle sim rig A · everything runs local
          </p>
          <div className="flex items-center gap-2">
            <StarDoodle className="w-5 h-5 floaty" />
            <span className="chipz text-[10px]!">egocentric episodic memory · hackathon build</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
