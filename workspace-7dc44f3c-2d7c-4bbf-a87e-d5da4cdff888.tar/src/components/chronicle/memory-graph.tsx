"use client";

import { useMemo } from "react";
import { motion } from "framer-motion";
import { useChronicle } from "@/lib/chronicle/chronicle-provider";
import { ZONES } from "@/lib/chronicle/world";

/* Zone anchor positions inside the 340x220 graph viewBox */
const ZONE_POS: Record<string, { x: number; y: number }> = {
  counter: { x: 74, y: 152 },
  table: { x: 258, y: 152 },
  shelf: { x: 166, y: 56 },
  floor: { x: 282, y: 62 },
};

/* Fan entities around their zone anchor so nothing overlaps */
function fanOffset(index: number, count: number): { dx: number; dy: number } {
  const spread = count <= 3 ? 1.15 : 1.5; // radians total arc
  const start = -Math.PI / 2 - spread / 2; // arc opening upward
  const angle = count === 1 ? -Math.PI / 2 : start + (spread * index) / (count - 1);
  // two staggered rings for dense zones
  const radius = count <= 3 ? 36 : index % 2 === 0 ? 46 : 62;
  return { dx: Math.cos(angle) * radius, dy: Math.sin(angle) * radius * 0.72 };
}

export function MemoryGraph() {
  const { snap, pingAndSelect, selected } = useChronicle();

  const nodes = snap.entities.filter((e) => e.seen);
  const v = snap.graphVersion; // re-render trigger

  /* per-zone fan positions */
  const posById = useMemo(() => {
    const byZone: Record<string, string[]> = {};
    for (const n of nodes) (byZone[n.zone] ??= []).push(n.id);
    const out: Record<string, { x: number; y: number }> = {};
    for (const [zone, ids] of Object.entries(byZone)) {
      const anchor = ZONE_POS[zone] ?? ZONE_POS.counter;
      ids.forEach((id, i) => {
        const off = fanOffset(i, ids.length);
        out[id] = {
          x: Math.max(26, Math.min(314, anchor.x + off.dx)),
          y: Math.max(30, Math.min(196, anchor.y + off.dy)),
        };
      });
    }
    return out;
  }, [nodes, v]);

  const edges = useMemo(() => {
    return nodes.map((e) => ({
      from: ZONE_POS[e.zone] ?? ZONE_POS.counter,
      to: posById[e.id] ?? ZONE_POS.counter,
      color: e.colorHex,
      id: e.id,
      held: e.state === "being carried",
    }));
  }, [nodes, posById, v]);

  return (
    <div className="zcard relative p-4 rot-r">
      <div className="tape tape-mint" style={{ width: 78 }} />
      <header className="flex items-center justify-between mb-1">
        <h2 className="font-display font-extrabold text-[15px]">memory graph</h2>
        <span className="font-hand text-[15px] text-inksoft">{nodes.length} nodes · {edges.length} links</span>
      </header>

      {nodes.length === 0 ? (
        <div className="h-[190px] flex flex-col items-center justify-center gap-1 border-2 border-dashed border-ink/30 rounded-xl">
          <svg viewBox="0 0 90 60" className="w-24 opacity-60" fill="none" aria-hidden>
            <circle cx="20" cy="30" r="7" stroke="#26221a" strokeWidth="2" strokeDasharray="4 3" />
            <circle cx="70" cy="20" r="7" stroke="#26221a" strokeWidth="2" strokeDasharray="4 3" />
            <circle cx="58" cy="46" r="7" stroke="#26221a" strokeWidth="2" strokeDasharray="4 3" />
            <path d="M27 28 Q 45 18 63 20 M27 33 Q 40 42 51 45" stroke="#26221a" strokeWidth="1.6" strokeDasharray="3 3" />
          </svg>
          <p className="font-hand text-lg text-inksoft">nodes grow here as I notice things</p>
        </div>
      ) : (
        <svg viewBox="0 0 340 220" className="w-full h-[200px] select-none" role="img" aria-label="Memory graph of objects, zones and relationships">
          {/* edges */}
          {edges.map((e) => {
            const isSel = selected === e.id;
            return (
              <g key={`e-${e.id}-${v}`}>
                <line
                  x1={e.from.x} y1={e.from.y} x2={e.to.x} y2={e.to.y}
                  stroke={isSel ? "#26221a" : e.color}
                  strokeWidth={isSel ? 3 : 2}
                  strokeDasharray={e.held ? "5 4" : "2.5 3"}
                  className={e.held ? "dashmove" : ""}
                  opacity={isSel ? 1 : 0.55}
                />
                {e.held && (
                  <circle r="3" fill="#ff6b4a">
                    <animateMotion dur="1.2s" repeatCount="indefinite" path={`M${e.from.x},${e.from.y} L${e.to.x},${e.to.y}`} />
                  </circle>
                )}
              </g>
            );
          })}

          {/* zone nodes */}
          {ZONES.map((z) => {
            const p = ZONE_POS[z.id];
            const active = nodes.some((n) => n.zone === z.id);
            return (
              <g key={z.id} transform={`translate(${p.x},${p.y})`}>
                <rect
                  x={-13} y={-9} width={26} height={18} rx={4}
                  fill={active ? "#26221a" : "#f1e8d2"}
                  stroke="#26221a" strokeWidth={2} strokeDasharray={active ? "0" : "4 3"}
                />
                <text x={0} y={26} textAnchor="middle" fontSize="9.5" fontWeight={700} fill="#26221a" style={{ fontFamily: "'IBM Plex Mono', monospace" }}>
                  {z.short}
                </text>
              </g>
            );
          })}

          {/* entity nodes */}
          {edges.map((e) => {
            const ent = nodes.find((n) => n.id === e.id)!;
            const isSel = selected === e.id;
            const wob = Math.sin(Date.now() / 900 + e.to.x) * 1.2;
            return (
              <motion.g
                key={`n-${e.id}-${v}`}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 18 }}
                style={{ cursor: "pointer", originX: `${e.to.x}px`, originY: `${e.to.y}px` }}
                onClick={() => pingAndSelect(e.id)}
              >
                {isSel && <circle cx={e.to.x} cy={e.to.y} r={15} fill="none" stroke="#ff6b4a" strokeWidth={2} className="ping-ring" />}
                <circle
                  cx={e.to.x} cy={e.to.y + wob}
                  r={10.5}
                  fill={ent.colorHex}
                  stroke="#26221a"
                  strokeWidth={2.5}
                />
                {/* flip label above when node fans above its zone anchor */}
                {(() => {
                  const anchor = ZONE_POS[ent.zone] ?? ZONE_POS.counter;
                  const above = e.to.y < anchor.y - 6;
                  const ly = above ? e.to.y - 17 + wob : e.to.y + 22 + wob;
                  return (
                    <text
                      x={e.to.x} y={ly}
                      textAnchor="middle" fontSize="10" fontWeight={800}
                      fill="#26221a"
                      style={{ fontFamily: "'Bricolage Grotesque', sans-serif", paintOrder: "stroke", stroke: "#fffcf4", strokeWidth: 3 }}
                    >
                      {ent.label}
                    </text>
                  );
                })()}
              </motion.g>
            );
          })}
        </svg>
      )}

      <div className="flex flex-wrap gap-1.5 mt-1">
        <span className="chipz chipz-secondary text-[9px]! py-0.5!">■ zone</span>
        <span className="chipz chipz-secondary text-[9px]! py-0.5!">● object</span>
        <span className="chipz chipz-secondary text-[9px]! py-0.5!">– – “on” link</span>
        <span className="chipz chipz-blush text-[9px]! py-0.5!">being carried →</span>
      </div>
    </div>
  );
}
