"use client";

/* Chronicle zine bits — cards, tape, stickers, doodles, pills */

import { ReactNode } from "react";
import { Mode } from "@/lib/chronicle/world";

export function ZCard({
  children,
  className = "",
  tape,
  rotate = "",
  title,
  note,
  icon,
  right,
}: {
  children: ReactNode;
  className?: string;
  tape?: "" | "tape-pink" | "tape-mint" | "tape-sky";
  rotate?: string;
  title?: string;
  note?: string;
  icon?: ReactNode;
  right?: ReactNode;
}) {
  return (
    <section className={`zcard relative p-4 ${rotate} ${className}`}>
      {tape && <div className={`tape ${tape}`} />}
      {(title || right) && (
        <header className="flex items-center justify-between gap-2 mb-3">
          <h2 className="font-display font-extrabold text-[15px] tracking-tight flex items-center gap-2">
            {icon}
            {title}
            {note && (
              <span className="font-hand text-[15px] text-inksoft font-medium hidden sm:inline">
                {note}
              </span>
            )}
          </h2>
          {right}
        </header>
      )}
      {children}
    </section>
  );
}

export function StatusPill({ mode }: { mode: Mode }) {
  const map: Record<Mode, { label: string; cls: string; dot: string }> = {
    idle: { label: "idle — no feed", cls: "chipz-secondary", dot: "bg-inksoft" },
    booting: { label: "booting…", cls: "chipz-mustard", dot: "bg-ink" },
    processing: { label: "processing", cls: "chipz-mustard", dot: "bg-coral rec-dot" },
    ready: { label: "memory warm", cls: "chipz-mint", dot: "bg-white rec-dot" },
    paused: { label: "paused", cls: "chipz-secondary", dot: "bg-inksoft" },
    error: { label: "signal lost", cls: "chipz-coral", dot: "bg-white rec-dot" },
  };
  const m = map[mode];
  return (
    <span className={`chipz ${m.cls} py-1! px-3! text-[12px]!`}>
      <span className={`w-2 h-2 rounded-full ${m.dot}`} />
      {m.label}
    </span>
  );
}

/* little hand-drawn arrow */
export function DoodleArrow({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 60 34" className={className} fill="none" aria-hidden>
      <path
        d="M4 6 C 22 4, 42 10, 50 24"
        stroke="#ff6b4a"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
      <path d="M50 24 L 41 21 M50 24 L 49 14" stroke="#ff6b4a" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

export function StarDoodle({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden>
      <path
        d="M12 2 L14 9 L21 9.5 L15.5 14 L17.5 21 L12 17 L6.5 21 L8.5 14 L3 9.5 L10 9 Z"
        stroke="#ffd34d"
        strokeWidth="1.8"
        fill="#ffd34d55"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function EyeLogo({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} fill="none" aria-hidden>
      <path
        d="M4 24 C 12 10, 36 10, 44 24 C 36 38, 12 38, 4 24 Z"
        fill="#fffcf4"
        stroke="#26221a"
        strokeWidth="3"
        strokeLinejoin="round"
      />
      <circle cx="24" cy="24" r="8.5" fill="#ffd34d" stroke="#26221a" strokeWidth="3" />
      <circle cx="24" cy="24" r="3.4" fill="#26221a" />
      <circle cx="27" cy="21" r="1.4" fill="#fffcf4" />
    </svg>
  );
}

export function EventIcon({ icon, className = "w-3.5 h-3.5" }: { icon: string; className?: string }) {
  if (icon === "up")
    return (
      <svg viewBox="0 0 16 16" className={className} fill="none" aria-hidden>
        <path d="M8 13 V3 M4 7 L8 3 L12 7" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  if (icon === "down")
    return (
      <svg viewBox="0 0 16 16" className={className} fill="none" aria-hidden>
        <path d="M8 3 V13 M4 9 L8 13 L12 9" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  if (icon === "bolt")
    return (
      <svg viewBox="0 0 16 16" className={className} fill="none" aria-hidden>
        <path d="M9 1 L3 9 H7.5 L7 15 L13 7 H8.5 Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" fill="currentColor" fillOpacity="0.2" />
      </svg>
    );
  return (
    <svg viewBox="0 0 16 16" className={className} fill="none" aria-hidden>
      <path d="M1.5 8 C 4 3.5, 12 3.5, 14.5 8 C 12 12.5, 4 12.5, 1.5 8 Z" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="8" cy="8" r="2.2" fill="currentColor" />
    </svg>
  );
}

export function GroundedBadge({ grounded }: { grounded: boolean }) {
  return grounded ? (
    <span className="chipz chipz-mint text-[10px]! py-0.5!">
      <svg viewBox="0 0 16 16" className="w-3 h-3" fill="none" aria-hidden>
        <path d="M3 8.5 L6.5 12 L13 4.5" stroke="#26221a" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      grounded
    </span>
  ) : (
    <span className="chipz chipz-blush text-[10px]! py-0.5!">
      <svg viewBox="0 0 16 16" className="w-3 h-3" fill="none" aria-hidden>
        <circle cx="8" cy="8" r="6.5" stroke="#26221a" strokeWidth="2" />
        <path d="M8 4.5 V8.5 M8 11.2 V11.4" stroke="#26221a" strokeWidth="2.2" strokeLinecap="round" />
      </svg>
      not in memory
    </span>
  );
}

export function MetricChip({ label, value, accent }: { label: string; value: string | number; accent?: string }) {
  return (
    <div className="chipz rounded-lg! py-1! px-2.5! gap-1.5">
      <span className={`font-display font-extrabold text-[13px] ${accent ?? ""}`}>{value}</span>
      <span className="text-[10px] uppercase tracking-wide text-inksoft font-bold">{label}</span>
    </div>
  );
}
