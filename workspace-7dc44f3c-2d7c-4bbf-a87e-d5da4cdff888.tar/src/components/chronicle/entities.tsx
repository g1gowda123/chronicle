"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useChronicle } from "@/lib/chronicle/chronicle-provider";
import { entityDef, fmtTs } from "@/lib/chronicle/world";

export function EntityList() {
  const { snap, pingAndSelect, selected, askEntity } = useChronicle();
  const [query, setQuery] = useState("");

  const q = query.trim().toLowerCase();
  const shown = snap.entities.filter((e) => {
    if (!q) return true;
    return (
      e.label.includes(q) ||
      e.colorName.toLowerCase().includes(q) ||
      e.zoneLabel.toLowerCase().includes(q) ||
      e.state.toLowerCase().includes(q)
    );
  });

  return (
    <div className="zcard relative p-4 rot-l">
      <div className="tape tape-pink" style={{ width: 88 }} />
      <header className="flex items-center justify-between mb-2">
        <h2 className="font-display font-extrabold text-[15px]">entity list</h2>
        <span className="font-hand text-[15px] text-inksoft">click one · poke my memory</span>
      </header>

      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="filter by label, colour, zone…"
        className="w-full zflat rounded-lg! bg-cardz px-3 py-2 text-[12.5px] outline-none focus:shadow-[3px_3px_0_0_var(--ink)] transition-shadow placeholder:text-inksoft/70 mb-2"
        aria-label="Filter entities"
      />

      <div className="nicescroll max-h-64 overflow-y-auto flex flex-col gap-1.5 pr-1">
        {shown.length === 0 && (
          <p className="font-hand text-lg text-inksoft py-6 text-center">
            {snap.mode === "idle" ? "nothing yet — feed me video" : "no match — try “red” or “table”"}
          </p>
        )}
        {shown.map((e) => (
          <motion.button
            key={e.id}
            layout
            onClick={() => pingAndSelect(e.id)}
            className={`text-left flex items-center gap-2.5 px-2.5 py-2 border-2 border-ink rounded-xl cursor-pointer transition-all ${
              selected === e.id ? "bg-mustard shadow-[3px_3px_0_0_var(--ink)]" : "bg-cardz hover:-translate-y-0.5 hover:shadow-[2px_2px_0_0_var(--ink)]"
            } ${e.seen ? "" : "opacity-45"}`}
          >
            <span
              className="w-5 h-5 rounded-full border-2 border-ink shrink-0"
              style={{ background: e.colorHex }}
              aria-hidden
            />
            <span className="grow min-w-0">
              <span className="flex items-center gap-1.5">
                <span className="font-display font-bold text-[13px]">{e.label}</span>
                {!e.seen && <span className="chipz chipz-secondary text-[9px]! py-0!">not seen yet</span>}
                {e.seen && e.conf < 0.7 && <span className="chipz chipz-blush text-[9px]! py-0!">low conf</span>}
              </span>
              <span className="block font-mono text-[10px] text-inksoft truncate">
                {e.seen ? `${e.zoneLabel} · ${e.state}` : "—"}
              </span>
            </span>
            {e.seen && (
              <span
                role="button"
                tabIndex={0}
                onClick={(ev) => {
                  ev.stopPropagation();
                  askEntity(e.id);
                }}
                onKeyDown={(ev) => {
                  if (ev.key === "Enter") {
                    ev.stopPropagation();
                    askEntity(e.id);
                  }
                }}
                className="chipz chipz-mint text-[9px]! py-0.5! shrink-0 hover:-translate-y-0.5 transition-transform"
                title={`ask where the ${e.label} is`}
              >
                ask
              </span>
            )}
          </motion.button>
        ))}
      </div>
    </div>
  );
}

export function EntityInspector() {
  const { snap, selected, askEntity } = useChronicle();
  const ent = snap.entities.find((e) => e.id === selected);
  const def = selected ? entityDef(selected) : null;

  if (!ent || !def) {
    return (
      <div className="zcard relative p-4">
        <div className="tape" style={{ width: 74 }} />
        <h2 className="font-display font-extrabold text-[15px] mb-1">entity card</h2>
        <div className="h-[150px] flex flex-col items-center justify-center gap-2 border-2 border-dashed border-ink/30 rounded-xl">
          <span className="text-3xl" aria-hidden>🔎</span>
          <p className="font-hand text-lg text-inksoft text-center px-4">
            pick an entity from the list or graph — its file opens here
          </p>
        </div>
      </div>
    );
  }

  const unavailable = def.unavailable ?? [];
  const row = (k: string, v: string | null, i: number) => (
    <div key={k} className={`flex items-baseline justify-between gap-2 py-1 ${i > 0 ? "border-t border-dashed border-ink/25" : ""}`}>
      <span className="font-mono text-[10px] uppercase tracking-wide text-inksoft">{k}</span>
      <span className={`text-[12px] font-bold text-right ${v === null ? "text-inksoft font-normal italic" : ""}`}>
        {v ?? "— unavailable —"}
      </span>
    </div>
  );

  const has = (k: string) => !unavailable.includes(k);

  return (
    <motion.div
      key={ent.id}
      initial={{ rotate: -1.2, scale: 0.95, opacity: 0 }}
      animate={{ rotate: 0.6, scale: 1, opacity: 1 }}
      transition={{ type: "spring", stiffness: 260, damping: 20 }}
      className="zcard relative p-4"
    >
      <div className="tape tape-sky" style={{ width: 80 }} />
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <span className="w-11 h-11 rounded-xl border-2 border-ink shadow-[2px_2px_0_0_var(--ink)]" style={{ background: ent.colorHex }} aria-hidden />
          <div>
            <h2 className="font-display font-extrabold text-lg leading-none">{ent.label}</h2>
            <span className="font-mono text-[10px] text-inksoft">memory #{String(snap.entities.indexOf(ent) + 1).padStart(3, "0")} · {Math.round(ent.conf * 100)}% conf</span>
          </div>
        </div>
        <button className="btnz btnz-mustard text-[11px]! py-1.5!" onClick={() => askEntity(ent.id)}>
          query it
        </button>
      </div>

      <div className="mt-3">
        {row("colour", has("colour") ? ent.colorName : null, 0)}
        {row("shape", has("shape") ? def.shape : null, 1)}
        {row("size", has("size") ? def.size : null, 2)}
        {row("brightness", has("brightness") ? def.brightness : null, 3)}
        {row("texture", has("texture") ? def.texture : null, 4)}
        {row("current state", ent.state, 5)}
        {row("zone", ent.zoneLabel, 6)}
        {row("support / container", has("container") ? (def.container ?? def.support[ent.zone] ?? null) : null, 7)}
        {row("first seen", ent.firstSeen !== null ? fmtTs(ent.firstSeen) : null, 8)}
        {row("last seen", ent.lastSeen !== null ? fmtTs(ent.lastSeen) : null, 9)}
      </div>
    </motion.div>
  );
}
