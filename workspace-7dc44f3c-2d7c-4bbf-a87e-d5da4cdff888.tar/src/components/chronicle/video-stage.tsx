"use client";

import { useRef, useState } from "react";
import { useChronicle } from "@/lib/chronicle/chronicle-provider";
import { fmtT } from "@/lib/chronicle/world";
import { DoodleArrow } from "./bits";

export function VideoStage() {
  const { snap, canvasRef, run, stop, unplug } = useChronicle();
  const fileRef = useRef<HTMLInputElement>(null);
  const [source, setSource] = useState("rig-a");
  const [uploaded, setUploaded] = useState<string | null>(null);
  const live = snap.mode === "processing" || snap.mode === "ready";
  const running = live || snap.mode === "booting";

  const onUpload = (f: File | undefined) => {
    if (!f) return;
    setUploaded(f.name);
    if (snap.mode === "idle" || snap.mode === "error") run();
  };

  return (
    <div className="relative">
      <div className="tape tape-sky" style={{ width: 110 }} />
      <div className="zcard p-3 sm:p-4 rot-l">
        {/* ---- the big screen ---- */}
        <div className="relative rounded-xl overflow-hidden border-2 border-ink bg-[#171410] aspect-[16/10]">
          <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" aria-label="Chronicle head-cam feed" />

          {/* scanline gloss overlay */}
          <div
            className="absolute inset-0 pointer-events-none opacity-20"
            style={{ background: "repeating-linear-gradient(0deg, rgba(255,255,255,0.05) 0 1px, transparent 1px 3px)" }}
          />

          {snap.mode === "idle" && (
            <div className="absolute inset-x-0 bottom-14 flex justify-center pointer-events-none">
              <div className="relative">
                <DoodleArrow className="w-14 h-8 absolute -right-16 -top-8 floaty" />
                <div className="zcard-sm px-4 py-2 rot-r2 bg-cardz font-hand text-xl">
                  press ▶ run — let me watch your morning
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ---- toolbar ---- */}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {/* run / stop */}
          {!running ? (
            <button className="btnz btnz-mint" onClick={run} aria-label="Run processing">
              <svg viewBox="0 0 16 16" className="w-3.5 h-3.5" fill="currentColor" aria-hidden>
                <path d="M4 2.5 L13 8 L4 13.5 Z" />
              </svg>
              Run
            </button>
          ) : (
            <button className="btnz btnz-coral" onClick={stop} aria-label="Stop processing">
              <svg viewBox="0 0 16 16" className="w-3 h-3.5" fill="currentColor" aria-hidden>
                <rect x="3" y="3" width="10" height="10" rx="1.5" />
              </svg>
              Stop
            </button>
          )}

          {/* source selector */}
          <div className="flex items-center gap-1 zflat p-1 rounded-[10px]! bg-cardz">
            <button
              onClick={() => setSource("rig-a")}
              className={`chipz border-0! transition-colors ${source === "rig-a" ? "chipz-ink" : "chipz-plain hover:opacity-70"}`}
            >
              sim rig A — kitchen
            </button>
            <button
              onClick={() => {
                setSource("upload");
                fileRef.current?.click();
              }}
              className={`chipz border-0! transition-colors ${source === "upload" ? "chipz-ink" : "chipz-plain hover:opacity-70"}`}
            >
              upload a clip
            </button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={(e) => onUpload(e.target.files?.[0])}
          />

          {/* timestamp */}
          <div className="chipz chipz-ink rounded-lg! font-mono px-3!" aria-live="polite">
            t = {fmtT(snap.t)}
          </div>

          <div className="grow" />

          {uploaded && source === "upload" && (
            <span className="chipz chipz-blush rounded-lg! max-w-44 truncate" title={uploaded}>
              ▶ {uploaded}
            </span>
          )}

          {/* unplug easter egg */}
          <button
            className={`btnz ${snap.mode === "error" ? "btnz-mustard" : ""}`}
            onClick={unplug}
            title="unplug the camera (error state demo)"
          >
            <svg viewBox="0 0 16 16" className="w-3.5 h-3.5" fill="none" aria-hidden>
              <path d="M5 2 V7 M11 2 V7 M4 7 H12 L11 11 H5 Z M8 11 V14.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            {snap.mode === "error" ? "plug back in" : "unplug feed"}
          </button>
        </div>
      </div>
    </div>
  );
}
