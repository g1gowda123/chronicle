"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useChronicle } from "@/lib/chronicle/chronicle-provider";
import { fmtTs } from "@/lib/chronicle/world";
import { EventIcon, ZCard } from "./bits";

/* ---------------- timeline of state changes ---------------- */
export function Timeline() {
  const { snap, pingAndSelect } = useChronicle();
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = scroller.current;
    if (el) el.scrollLeft = el.scrollWidth;
  }, [snap.events.length]);

  return (
    <ZCard
      title="timeline of state changes"
      note="the day, minute by minute"
      tape=""
      rotate="rot-l"
      icon={
        <svg viewBox="0 0 16 16" className="w-4 h-4" fill="none" aria-hidden>
          <path d="M2 8 H14 M4 5 L2 8 L4 11 M12 5 L14 8 L12 11" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      }
    >
      {snap.events.length === 0 ? (
        <div className="h-20 flex items-center justify-center border-2 border-dashed border-ink/30 rounded-xl">
          <p className="font-hand text-lg text-inksoft">events land here once I start noticing things…</p>
        </div>
      ) : (
        <div ref={scroller} className="nicescroll overflow-x-auto pb-1">
          <div className="flex items-stretch gap-0 min-w-max pt-3">
            {snap.events.map((e, i) => (
              <div key={e.id} className="flex items-stretch">
                <button
                  onClick={() => pingAndSelect(e.entityId)}
                  className="group relative flex flex-col items-center w-[118px] cursor-pointer"
                  title={e.text}
                >
                  <span className="font-mono text-[9.5px] text-inksoft">{fmtTs(e.t)}</span>
                  <span
                    className={`my-1 w-3.5 h-3.5 rotate-45 border-2 border-ink flex items-center justify-center transition-transform group-hover:scale-125 ${
                      e.kind === "pick-up" ? "bg-coral" : e.kind === "place" ? "bg-mint" : e.kind === "state" ? "bg-sky" : "bg-mustard"
                    }`}
                  />
                  <span className="font-bold text-[10.5px] leading-tight text-center">{e.text}</span>
                </button>
                {i < snap.events.length - 1 && <div className="self-center w-6 border-t-2 border-dotted border-ink/40" />}
              </div>
            ))}
          </div>
        </div>
      )}
    </ZCard>
  );
}

/* ---------------- actions & interactions ---------------- */
export function ActionList() {
  const { snap, pingAndSelect } = useChronicle();
  const actions = [...snap.events].reverse().filter((e) => e.kind === "pick-up" || e.kind === "place" || e.kind === "state").slice(0, 7);

  return (
    <ZCard title="actions & interactions" note="hands were involved" tape="tape-mint" rotate="rot-r">
      {actions.length === 0 ? (
        <p className="font-hand text-lg text-inksoft py-5 text-center">no drama yet — it's early</p>
      ) : (
        <ul className="flex flex-col gap-1.5">
          {actions.map((e) => (
            <motion.li
              key={e.id}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-2 bg-cardz border-2 border-ink rounded-lg px-2.5 py-1.5"
            >
              <span
                className={`w-6 h-6 rounded-md border-2 border-ink flex items-center justify-center shrink-0 ${
                  e.kind === "pick-up" ? "bg-coral text-white" : e.kind === "place" ? "bg-mint text-white" : "bg-sky text-ink"
                }`}
              >
                <EventIcon icon={e.icon} />
              </span>
              <span className="text-[12px] font-bold grow leading-tight">{e.text}</span>
              <span className="font-mono text-[10px] text-inksoft">{fmtTs(e.t)}</span>
            </motion.li>
          ))}
        </ul>
      )}
    </ZCard>
  );
}

/* ---------------- verification queue ---------------- */
export function VerifyQueue() {
  const { snap, verify } = useChronicle();
  const pending = snap.verifications.filter((v) => v.status === "pending");

  return (
    <ZCard title="verification queue" note="am I sure? you decide" tape="tape-pink" rotate="rot-l2">
      {pending.length === 0 ? (
        <div className="flex items-center gap-2 py-4 justify-center">
          <span className="chipz chipz-mint">all clear</span>
          <span className="font-hand text-lg text-inksoft">nothing needs a human eye</span>
        </div>
      ) : (
        <ul className="flex flex-col gap-2">
          {pending.map((v) => (
            <li key={v.id} className="bg-cardz border-2 border-ink rounded-lg px-2.5 py-2">
              <div className="flex items-center gap-2">
                <span className="font-display font-bold text-[13px] grow">
                  “{v.label}”? <span className="font-mono text-[10px] text-coral">{Math.round(v.conf * 100)}%</span>
                </span>
                <button className="btnz btnz-mint px-2! py-1! text-[11px]!" onClick={() => verify(v.id, true)} aria-label={`Confirm ${v.label}`}>
                  ✓ it's right
                </button>
                <button className="btnz btnz-coral px-2! py-1! text-[11px]!" onClick={() => verify(v.id, false)} aria-label={`Reject ${v.label}`}>
                  ✗ nope
                </button>
              </div>
              <div className="mt-1.5 h-2 rounded-full border border-ink/40 overflow-hidden bg-secondary">
                <div className="h-full bg-blush" style={{ width: `${v.conf * 100}%` }} />
              </div>
            </li>
          ))}
        </ul>
      )}
      {snap.verifications.some((v) => v.status !== "pending") && (
        <p className="font-mono text-[9.5px] text-inksoft mt-2">
          {snap.verifications.filter((v) => v.status === "confirmed").length} confirmed ·{" "}
          {snap.verifications.filter((v) => v.status === "rejected").length} rejected — thanks human
        </p>
      )}
    </ZCard>
  );
}

/* ---------------- model status ---------------- */
export function ModelStatus() {
  const { snap } = useChronicle();
  const live = snap.mode === "processing" || snap.mode === "ready";
  return (
    <ZCard title="local models" note="all on-device, no cloud" tape="tape-sky" rotate="rot-r2">
      <div className="flex flex-col gap-2.5">
        {[
          { name: "chron-vision-1.1", desc: "detect + track", stat: live ? `${24 + Math.round(Math.sin(snap.t) * 2)} ms/frame` : "asleep", load: live ? 0.62 : 0.08, color: "bg-mint" },
          { name: "prop-scanner", desc: "colour · shape · texture", stat: live ? "warm" : "idle", load: live ? 0.34 : 0.05, color: "bg-mustard" },
          { name: "memory-llm-3b", desc: "answers from notes only", stat: live ? `${(38 + Math.round(Math.cos(snap.t * 2) * 6))} tok/s` : "napping", load: live ? 0.47 : 0.03, color: "bg-coral" },
        ].map((m) => (
          <div key={m.name} className="bg-cardz border-2 border-ink rounded-lg px-2.5 py-2">
            <div className="flex items-baseline justify-between gap-2">
              <span className="font-mono font-semibold text-[11.5px]">{m.name}</span>
              <span className="font-mono text-[10px] text-inksoft">{m.stat}</span>
            </div>
            <div className="flex items-center gap-2 mt-1">
              <div className="grow h-2 rounded-full border border-ink/40 overflow-hidden bg-secondary">
                <motion.div
                  className={`h-full ${m.color}`}
                  animate={{ width: `${m.load * 100}%` }}
                  transition={{ duration: 0.6 }}
                />
              </div>
              <span className="font-mono text-[9px] text-inksoft w-24 text-right">{m.desc}</span>
            </div>
          </div>
        ))}
      </div>
    </ZCard>
  );
}

/* ---------------- telemetry ---------------- */
export function Telemetry() {
  const { snap } = useChronicle();
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = box.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [snap.log.length]);

  return (
    <ZCard title="pipeline log" note="raw thoughts, unfiltered" rotate="rot-l">
      <div ref={box} className="nicescroll h-44 overflow-y-auto rounded-lg bg-ink p-2.5 font-mono text-[10.5px] leading-[1.7] text-paper">
        {snap.log.length === 0 ? (
          <p className="text-paper/50">{"// waiting for the feed…"}</p>
        ) : (
          snap.log.map((l, i) => (
            <p key={i} className="whitespace-pre-wrap">
              <span className="text-paper/50">[{fmtTs(l.t)}]</span>{" "}
              <span className={l.level === "ok" ? "text-mint" : l.level === "warn" ? "text-blush" : "text-sky"}>
                {l.level.toUpperCase()}
              </span>{" "}
              {l.text}
            </p>
          ))
        )}
      </div>
    </ZCard>
  );
}
