"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useChronicle } from "@/lib/chronicle/chronicle-provider";
import { fmtTs } from "@/lib/chronicle/world";
import { EyeLogo, GroundedBadge } from "./bits";

const THINKING_LINES = [
  "flipping through my memory…",
  "rewatching the good parts…",
  "cross-checking my notes…",
  "squinting at frame buffers…",
];

export function ChatPanel() {
  const { snap, messages, thinking, send, suggestions, pingAndSelect } = useChronicle();
  const [value, setValue] = useState("");
  const [sugOffset, setSugOffset] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, thinking]);

  useEffect(() => {
    const iv = window.setInterval(() => setSugOffset((o) => (o + 1) % suggestions.length), 7000);
    return () => window.clearInterval(iv);
  }, [suggestions.length]);

  const visibleSugs = [0, 1, 2, 3].map((i) => suggestions[(sugOffset + i) % suggestions.length]);

  const submit = () => {
    if (!value.trim()) return;
    send(value);
    setValue("");
  };

  const onCitation = (entityId?: string, t?: number) => {
    if (entityId) pingAndSelect(entityId);
    if (t !== undefined) console.info(`cite @ ${fmtTs(t)}`);
  };

  return (
    <div className="zcard relative p-4 rot-r flex flex-col h-[480px]">
      <div className="tape" style={{ width: 84 }} />
      <header className="flex items-center justify-between mb-2">
        <h2 className="font-display font-extrabold text-[15px] flex items-center gap-2">
          ask my memory
          <span className="font-hand text-[15px] text-inksoft font-medium hidden sm:inline">
            (grounded or I say so)
          </span>
        </h2>
        <span className="chipz chipz-secondary text-[10px]!">
          {snap.mode === "idle" ? "wake me up first" : snap.mode === "processing" ? "still watching…" : `${snap.entities.filter((e) => e.seen).length} objects remembered`}
        </span>
      </header>

      {/* messages */}
      <div ref={scrollRef} className="nicescroll grow overflow-y-auto pr-1 flex flex-col gap-3 py-1">
        <AnimatePresence initial={false}>
          {messages.map((m) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 14, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ type: "spring", stiffness: 380, damping: 26 }}
              className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
            >
              {m.role === "chron" && (
                <div className="shrink-0 w-8 h-8 rounded-full border-2 border-ink bg-mustard flex items-center justify-center mr-2 mt-1 z-10">
                  <EyeLogo className="w-6 h-6" />
                </div>
              )}
              <div className={`max-w-[85%] ${m.role === "user" ? "items-end" : ""}`}>
                <div
                  className={`px-3.5 py-2.5 text-[13.5px] leading-relaxed whitespace-pre-line border-2 border-ink rounded-xl ${
                    m.role === "user"
                      ? "bg-ink text-paper rounded-br-sm"
                      : m.grounded === false
                        ? "bg-blush/60 rounded-bl-sm"
                        : "bg-cardz rounded-bl-sm shadow-[3px_3px_0_0_var(--ink)]"
                  }`}
                >
                  {m.text}
                </div>

                {m.role === "chron" && (
                  <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                    {m.grounded !== undefined && <GroundedBadge grounded={m.grounded} />}
                    {m.citations?.map((c, i) => (
                      <button
                        key={i}
                        onClick={() => onCitation(c.entityId, c.t)}
                        className="chipz chipz-mustard text-[10px]! py-0.5! hover:-translate-y-0.5 transition-transform cursor-pointer"
                        title={`jump to ${fmtTs(c.t)}`}
                      >
                        <svg viewBox="0 0 16 16" className="w-3 h-3" fill="none" aria-hidden>
                          <circle cx="8" cy="8" r="6.2" stroke="#26221a" strokeWidth="1.8" />
                          <path d="M8 4.8 V8 L10.2 9.4" stroke="#26221a" strokeWidth="1.8" strokeLinecap="round" />
                        </svg>
                        {fmtTs(c.t)} · {c.label}
                      </button>
                    ))}
                  </div>
                )}

                {m.role === "chron" && m.frameUrl && (
                  <div className="mt-1.5 inline-block zcard-sm rounded-lg! p-1 rot-l">
                    <img
                      src={m.frameUrl}
                      alt={`supporting frame from the feed`}
                      className="rounded-md border border-ink/60 w-40 h-25 object-cover"
                    />
                    <div className="font-mono text-[9px] text-inksoft text-center mt-0.5">frame evidence ↑</div>
                  </div>
                )}
                {m.stamp && (
                  <div className={`font-mono text-[9px] text-inksoft mt-0.5 ${m.role === "user" ? "text-right" : ""}`}>
                    {m.role === "user" ? "you" : "chronicle"} · {m.stamp}
                  </div>
                )}
              </div>
            </motion.div>
          ))}

          {thinking && (
            <motion.div key="thinking" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full border-2 border-ink bg-mustard flex items-center justify-center wiggle">
                <EyeLogo className="w-6 h-6" />
              </div>
              <div className="chipz chipz-plain italic font-hand text-base!">
                {THINKING_LINES[messages.length % THINKING_LINES.length]}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* suggestions */}
      <div className="flex gap-1.5 flex-wrap mt-2">
        {visibleSugs.map((s, i) => (
          <button
            key={`${s}-${i}`}
            onClick={() => {
              send(s);
              inputRef.current?.focus();
            }}
            className={`chipz text-[11px]! hover:-translate-y-0.5 hover:shadow-[2px_2px_0_0_var(--ink)] transition-all cursor-pointer ${
              i === 0 ? "bg-mustard" : "bg-cardz"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {/* input */}
      <div className="mt-2.5 flex gap-2">
        <input
          ref={inputRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder={snap.mode === "idle" ? "press Run first, then ask me anything…" : "e.g. where was the cup before the table?"}
          className="grow zflat rounded-xl! bg-cardz px-3.5 py-2.5 text-[13.5px] outline-none focus:shadow-[3px_3px_0_0_var(--ink)] transition-shadow placeholder:text-inksoft/70"
          aria-label="Ask Chronicle a question"
        />
        <button className="btnz btnz-ink px-4!" onClick={submit} aria-label="Send question">
          <svg viewBox="0 0 16 16" className="w-4 h-4" fill="none" aria-hidden>
            <path d="M2 8 L14 2 L9.5 14 L7.5 9 Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" fill="currentColor" fillOpacity="0.25" />
          </svg>
          ask
        </button>
      </div>
    </div>
  );
}
